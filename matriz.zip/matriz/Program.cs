﻿using System;

namespace matriz
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Informe qual atividade de matrizes deseja resolver ou 9 para sair...");
            int atividade = int.Parse(Console.ReadLine());

            while(atividade != 9)
            {
                int value = 0;

                switch (atividade)
                {
                    case 0:
                        value = int.Parse(Console.ReadLine());
                        int[,] val = new int[value, value];
                        int count = 0;
                        string mainDiagonal = "";

                        for(int x = 0; x < value; x++)
                        {
                            string[] m = Console.ReadLine().Split(' ');

                            for(int y = 0; y < value; y++)
                            {
                                val[x, y] = int.Parse(m[y]);
                            }
                        }

                        for(int x = 0; x < value; x++)
                        {
                            mainDiagonal += val[x, x].ToString() + " ";

                            for(int y = 0; y < value; y++)
                            {

                                if (val[x, y] < 0)
                                    count++;
                            }
                        }
                                                
                        Console.WriteLine($"Main Diagonal: {mainDiagonal.Remove(mainDiagonal.Length - 1, 1)}");
                        Console.WriteLine($"Negative numbers: {count}");
                        break;
                    case 1:
                        Console.Write("Digite dois números inteiros: ");
                        string[] values = Console.ReadLine().Split(' ');

                        int[,] mn = new int[int.Parse(values[0]), int.Parse(values[1])];

                        Console.WriteLine($"Digite os valores da matriz [{int.Parse(values[0])}, {int.Parse(values[1])}] :");

                        for (int x = 0; x < int.Parse(values[0]); x++)
                        {
                            string[] values2 = Console.ReadLine().Split(' ');

                            for (int y = 0; y < int.Parse(values[1]); y++)
                            {
                                mn[x, y] = int.Parse(values2[y]);
                            }
                        }

                        value = int.Parse(Console.ReadLine());

                        for (int x = 0; x < int.Parse(values[0]); x++)
                        {
                            for (int y = 0; y < int.Parse(values[1]); y++)
                            {
                                if (mn[x, y] == value)
                                {
                                    Console.WriteLine($"Position {x},{y}:");
                                    if (y - 1 >= 0) Console.WriteLine($"Left: {mn[x, y - 1]}");
                                    if (y + 1 >= 0 && y + 1 < mn.GetLength(x)) Console.WriteLine($"Right: {mn[x, y + 1]}");
                                    if (x - 1 >= 0) Console.WriteLine($"Up: {mn[x - 1, y]}");
                                    if (x + 1 >= 0 && x + 1 < mn.GetLength(x)) Console.WriteLine($"Down: {mn[x + 1, y]}");
                                }
                            }
                        }
                        break;
                    default:
                        Console.WriteLine("Valor inválido, digite novamente...");
                        atividade = int.Parse(Console.ReadLine());
                        break;
                }
            } 
        }
    }
}
