﻿using introducao_linq.Entities;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

namespace introducao_linq
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter full file path: ");
            string path = Console.ReadLine();

            Console.Write("Enter salary: ");
            double salary = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);

            List<People> peoples = new List<People>();

            //Modelo de arquivo texto: Nome,Email,Salário
            using (StreamReader sr = File.OpenText(path))
            {
                while (!sr.EndOfStream)
                {
                    string[] fields = sr.ReadLine().Split(',');
                    peoples.Add(new People(fields[0], fields[1], double.Parse(fields[2], CultureInfo.InvariantCulture)));
                }
            }

            Console.WriteLine($"Email of people whose salary is more than {salary.ToString("F2", CultureInfo.InvariantCulture)}");

            foreach (var people in peoples.Where(x => x.Salary > salary).Select(x => x.Email))
                Console.WriteLine(people);
            
            Console.Write($"Sum of salary of people whose name starts with 'M': {peoples.Where(x => x.Name.StartsWith('M')).Sum(x => x.Salary).ToString("F2", CultureInfo.InvariantCulture)}");
        }
    }
}
