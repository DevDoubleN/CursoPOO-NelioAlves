﻿using System;
using System.Collections.Generic;
using System.Globalization;
using heranca_polimorfismo_2.Entities;

namespace heranca_polimorfismo_2
{
    class Program
    {
        static void Main(string[] args)
        {
            List<TaxPayer> taxPayers = new List<TaxPayer>();
            double taxes = 0;

            Console.Write("Enter the number of tax payers: ");
            int payers = int.Parse(Console.ReadLine());

            for(int x = 0; x < payers; x++)
            {
                Console.WriteLine($"Tax payer #{x + 1} data: ");

                Console.Write("Individual or company (i/c)? ");
                char ic = char.Parse(Console.ReadLine());

                Console.Write("Name: ");
                string name = Console.ReadLine();

                Console.Write("Anual income: ");
                double anualIncome = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);

                if (ic == 'c')
                {
                    Console.Write("Number of employees: ");
                    int numberOfEmployees = int.Parse(Console.ReadLine());

                    taxPayers.Add(new Company(numberOfEmployees, name, anualIncome));
                }
                else
                {
                    Console.Write("Health expenditures: ");
                    double healthExpenditures = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);

                    taxPayers.Add(new Individual(name, anualIncome, healthExpenditures));
                }
            }

            Console.WriteLine("\n\nTAXES PAID:");

            foreach(TaxPayer payer in taxPayers)
            {
                Console.WriteLine(payer.ToString());

                taxes += payer.Tax();
            }

            Console.WriteLine($"\n\nTOTAL TAXES: $ {taxes.ToString("F2", CultureInfo.InvariantCulture)}");
        }
    }
}
