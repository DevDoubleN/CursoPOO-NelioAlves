﻿using System;

namespace estrutura_while
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Informe qual exercício deseja fazer ou pressione 0 para sair...");
                int exercicioEscolhido = int.Parse(Console.ReadLine());
                Console.Clear();

                while (exercicioEscolhido != 0)
                {
                    switch (exercicioEscolhido)
                    {
                        case 1:
                            // Escreva um programa que repita a leitura de uma senha até que ela seja válida. Para cada leitura de senha 
                            // incorreta informada, escrever a mensagem "Senha Invalida".Quando a senha for informada corretamente deve ser
                            // impressa a mensagem "Acesso Permitido" e o algoritmo encerrado.Considere que a senha correta é o valor 2002.

                            const string senha = "2002";
                            Console.WriteLine("Digite a senha: ");
                            string senhaDigitada = Console.ReadLine();

                            while (senha != senhaDigitada)
                            {
                                Console.Clear();
                                Console.WriteLine("Senha inválida! Digite Novamente!!!");
                                senhaDigitada = Console.ReadLine();
                            }

                            Console.WriteLine("Acesso permitido!!!");

                            break;
                        case 2:
                            // Escreva um programa para ler as coordenadas (X, Y) de uma quantidade indeterminada de pontos no sistema
                            // cartesiano.Para cada ponto escrever o quadrante a que ele pertence. O algoritmo será encerrado quando pelo
                            // menos uma de duas coordenadas for NULA(nesta situação sem escrever mensagem alguma).

                            Console.WriteLine("Informe as coordenadas: ");
                            string[] coordenadasValue = Console.ReadLine().Split(" ");
                            int[] coordenadas = new int[coordenadasValue.Length];
                            for (int x = 0; x < coordenadasValue.Length; x++)
                                coordenadas[x] = int.Parse(coordenadasValue[x]);

                            while (coordenadas[0] != 0 || coordenadas[1] != 0)
                            {
                                if (coordenadas[0] > 0 && coordenadas[1] > 0)
                                    Console.WriteLine("Primeiro!");
                                else if (coordenadas[0] < 0 && coordenadas[1] > 0)
                                    Console.WriteLine("Segundo!");
                                else if (coordenadas[0] < 0 && coordenadas[1] < 0)
                                    Console.WriteLine("Terceiro!");
                                else if (coordenadas[0] > 0 && coordenadas[1] < 0)
                                    Console.WriteLine("Quarto!");
                                else
                                {
                                    Console.Clear();
                                    break;
                                }

                                coordenadasValue = Console.ReadLine().Split(" ");
                                for (int x = 0; x < coordenadasValue.Length; x++)
                                    coordenadas[x] = int.Parse(coordenadasValue[x]);
                            }

                            break;
                        case 3:
                            // Um Posto de combustíveis deseja determinar qual de seus produtos tem a preferência de seus clientes. Escreva
                            // um algoritmo para ler o tipo de combustível abastecido(codificado da seguinte forma: 1.Álcool 2.Gasolina 3.Diesel
                            // 4.Fim). Caso o usuário informe um código inválido(fora da faixa de 1 a 4) deve ser solicitado um novo código(até
                            // que seja válido). O programa será encerrado quando o código informado for o número 4.Deve ser escrito a
                            // mensagem: "MUITO OBRIGADO" e a quantidade de clientes que abasteceram cada tipo de combustível, conforme exemplo.

                            Console.WriteLine("Digite o tipo de combustível abastecido: ");
                            int tipo = int.Parse(Console.ReadLine());
                            int alc = 0, gas = 0, die = 0;

                            while (tipo != 4)
                            {
                                if (tipo == 1)
                                    alc++;
                                else if (tipo == 2)
                                    gas++;
                                else if (tipo == 3)
                                    die++;

                                tipo = int.Parse(Console.ReadLine());
                            }

                            Console.Clear();
                            Console.WriteLine("Muito obrigado!");
                            Console.WriteLine($"Álcool: {alc}\nGasolina: {gas}\nDiesel: {die}");

                            break;
                    }

                    Console.WriteLine("Informe qual exercício deseja fazer ou pressione 0 para sair...");
                    exercicioEscolhido = int.Parse(Console.ReadLine());
                    Console.Clear();
                }
            }
            catch
            {
                Console.WriteLine("Opção inválida!!!");
            }
        }
    }
}
