﻿namespace interfaces_2.Models.Enums
{
    enum Color
    {
        White,
        Black,
        Orange,
        Green,
        Brown,
        Red,
        Blue,
        Yellow,
        Golden,
        Pink
    }
}
