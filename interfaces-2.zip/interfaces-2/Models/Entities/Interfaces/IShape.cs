﻿namespace interfaces_2.Models.Entities.Interfaces
{
    interface IShape
    {
        double Area();
    }
}
