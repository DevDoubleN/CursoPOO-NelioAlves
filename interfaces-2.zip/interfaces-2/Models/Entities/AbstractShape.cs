﻿using interfaces_2.Models.Entities.Interfaces;
using interfaces_2.Models.Enums;

namespace interfaces_2.Models.Entities
{
    abstract class AbstractShape : IShape
    {
        public Color Color { get; set; }
        public abstract double Area();
    }
}
