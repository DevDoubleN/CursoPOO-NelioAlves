﻿using heranca_multipla.Devices;
using System;
using System.Text;

namespace heranca_multipla
{
    class Program
    {
        static void Main(string[] args)
        {
            StringBuilder sb = new StringBuilder();

            Printer p = new Printer() { SerialNumber = 1080 };
            p.ProcessDoc("My letter");
            p.Print("My letter");

            Scanner s = new Scanner() { SerialNumber = 2003 };
            s.ProcessDoc("My Email");
            Console.WriteLine(s.Scan());

            ComboDevice c = new ComboDevice() { SerialNumber = 3921 };
            c.ProcessDoc("My dissertation");
            c.Print("My dissertation");
            Console.WriteLine(c.Scan());

            sb.Append("\n\nA lógica deste programa consiste em evitar o problema do diamante, onde ao criar a classe abstrata Device e herdá-la nas classes Printer e Scanner, ");
            sb.AppendLine("impedimos de que as mesmas se tornassem superclasse de outra classe, pois implementam o mesmo método da classe abstrata, gerando ambiguidade.");
            sb.AppendLine("A solução consiste em manter a herança nas classes Printer e Scanner, e criar a interface para estabelecer um contrato apenas com a parte que importa das superclasses.");
            sb.Append("Após isso, as superclasses implementam seus respectivos contratos e a nova classe gerada ComboDevice, passa a herdar diretamente da classe");
            sb.Append("abstrata Device e implementa as interfaces de suas superclasses.");
            Console.WriteLine(sb.ToString());
        }
    }
}
