﻿namespace heranca_multipla.Devices
{
    interface IScanner
    {
        string Scan();
    }
}
