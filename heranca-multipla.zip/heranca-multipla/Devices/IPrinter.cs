﻿namespace heranca_multipla.Devices
{
    interface IPrinter
    {
        void Print(string document); 
    }
}
