﻿using System;
using System.Collections.Generic;
using System.IO;

namespace dictionary
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter file full path: ");
            string path = Console.ReadLine();
            Dictionary<string, int> candidates = new Dictionary<string, int>();

            try
            {
                using (StreamReader sr = File.OpenText(path))
                {
                    while (!sr.EndOfStream)
                    {
                        //O conteúdo do arquivo trata-se do nome do candidato e a quantidade de votos separados por vírgula.
                        //Ex: Maguito,35

                        string[] lines = sr.ReadLine().Split(',');

                        if (candidates.ContainsKey(lines[0]))
                            candidates[lines[0]] += int.Parse(lines[1]);
                        else
                            candidates.Add(lines[0], int.Parse(lines[1]));
                    }
                }

                foreach (KeyValuePair<string, int> key in candidates)
                {
                    Console.WriteLine(key.Key + ": " + key.Value);
                }
            }
            catch(IOException e)
            {
                throw new IOException($"An error occurred! \n{e.Message}");
            }
        }
    }
}
