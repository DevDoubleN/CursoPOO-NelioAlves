﻿using System;
using System.Globalization;

namespace estrutura_sequencial
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Informe qual exercício deseja fazer ou pressione 0 para sair...");
                int exercicioEscolhido = int.Parse(Console.ReadLine());
                Console.Clear();

                while (exercicioEscolhido != 0)
                {
                    switch (exercicioEscolhido)
                    {
                        case 1:
                            //Faça um programa para ler dois valores inteiros, e depois mostrar na tela a soma desses números com uma 
                            //mensagem explicativa, conforme exemplos.

                            Console.WriteLine("Digite o primeiro número: ");
                            int n1 = int.Parse(Console.ReadLine());
                            Console.WriteLine("Digite o segundo número: ");
                            int n2 = int.Parse(Console.ReadLine());
                            Console.WriteLine($"SOMA = {n1 + n2}");

                            break;
                        case 2:
                            //Faça um programa para ler o valor do raio de um círculo, e depois mostrar o valor da área deste círculo com quatro 
                            //casas decimais conforme exemplos.
                            // Fórmula: area = pi * raio²
                            // Considere o valor de π = 3.14159

                            double pi = 3.14159;
                            Console.WriteLine("Digite o valor do raio: ");
                            double raio = double.Parse(Console.ReadLine());
                            double area = pi * Math.Pow(raio, 2);
                            Console.WriteLine($"Área = {area.ToString("F4", CultureInfo.InvariantCulture)}");

                            break;
                        case 3:
                            // Fazer um programa para ler quatro valores inteiros A, B, C e D. A seguir, calcule e mostre a diferença do produto 
                            // de A e B pelo produto de C e D segundo a fórmula: DIFERENCA = (A * B - C * D)

                            Console.WriteLine("Digite o valor de A: "); ;
                            int A = int.Parse(Console.ReadLine());
                            Console.WriteLine("Digite o valor de B: "); ;
                            int B = int.Parse(Console.ReadLine());
                            Console.WriteLine("Digite o valor de C: "); ;
                            int C = int.Parse(Console.ReadLine());
                            Console.WriteLine("Digite o valor de D: "); ;
                            int D = int.Parse(Console.ReadLine());
                            Console.WriteLine($"Diferença: {(A * B - C * D)}");

                            break;
                        case 4:
                            // Fazer um programa que leia o número de um funcionário, seu número de horas trabalhadas, o valor que recebe por
                            // hora e calcula o salário desse funcionário.A seguir, mostre o número e o salário do funcionário, com duas casas
                            // decimais

                            Console.WriteLine("Digite o número do funcionário: ");
                            int numero = int.Parse(Console.ReadLine());
                            Console.WriteLine("Digite a quantidade de horas trabalhadas: ");
                            int qtdHoras = int.Parse(Console.ReadLine());
                            Console.WriteLine("Digite o valor recebido por hora trabalhada: ");
                            double valor = double.Parse(Console.ReadLine());
                            double salario = qtdHoras * valor;
                            Console.WriteLine($"Número: {numero}. \nSalário: U$ {salario.ToString("F2", CultureInfo.InvariantCulture)}.");

                            break;
                        case 5:
                            // Fazer um programa para ler o código de uma peça 1, o número de peças 1, o valor unitário de cada peça 1, o 
                            // código de uma peça 2, o número de peças 2 e o valor unitário de cada peça 2.Calcule e mostre o valor a ser pago.

                            Console.WriteLine("Digite o código da peça: ");
                            int codigo = int.Parse(Console.ReadLine());
                            Console.WriteLine("Digite a quantidade de peças: ");
                            int quantidade = int.Parse(Console.ReadLine());
                            Console.WriteLine($"Digite o valor unitário de cada peça do código {codigo}: ");
                            double preco = double.Parse(Console.ReadLine());
                            Console.WriteLine("Digite o código da peça: ");
                            int codigo2 = int.Parse(Console.ReadLine());
                            Console.WriteLine("Digite a quantidade de peças: ");
                            int quantidade2 = int.Parse(Console.ReadLine());
                            Console.WriteLine($"Digite o valor unitário de cada peça do código {codigo}: ");
                            double preco2 = double.Parse(Console.ReadLine());
                            double valorTotal = (quantidade * preco) + (quantidade2 * preco2);
                            Console.WriteLine($"Valor a pagar: R$ {valorTotal.ToString("F2")}");

                            break;
                        case 6:
                            //Fazer um programa que leia três valores com ponto flutuante de dupla precisão: A, B e C.Em seguida, calcule e
                            //mostre: 
                            //a) a área do triângulo retângulo que tem A por base e C por altura. 
                            //b) a área do círculo de raio C. (pi = 3.14159)
                            //c) a área do trapézio que tem A e B por bases e C por altura.
                            //d) a área do quadrado que tem lado B. 
                            //e) a área do retângulo que tem lados A e B.

                            Console.WriteLine("Digite o valor de A: ");
                            double dblA = double.Parse(Console.ReadLine());
                            Console.WriteLine("Digite o valor de B: ");
                            double dblB = double.Parse(Console.ReadLine());
                            Console.WriteLine("Digite o valor de C: ");
                            double dblC = double.Parse(Console.ReadLine());
                            double triangulo = (dblA * dblC) / 2;
                            double circulo = Math.Pow(dblC, 2) * 3.14159;
                            double trapezio = ((dblA + dblB) * dblC) / 2;
                            double quadrado = dblB * dblB;
                            double retangulo = dblA * dblB;
                            Console.WriteLine($"Triângulo: {triangulo.ToString("F3", CultureInfo.InvariantCulture)}");
                            Console.WriteLine($"Círculo: {circulo.ToString("F3", CultureInfo.InvariantCulture)}");
                            Console.WriteLine($"Trapézio: {trapezio.ToString("F3", CultureInfo.InvariantCulture)}");
                            Console.WriteLine($"Quadrado: {quadrado.ToString("F3", CultureInfo.InvariantCulture)}");
                            Console.WriteLine($"Retângulo: {retangulo.ToString("F3", CultureInfo.InvariantCulture)}");

                            break;
                    }

                    Console.WriteLine("Informe qual exercício deseja fazer ou pressione 0 para sair...");
                    exercicioEscolhido = int.Parse(Console.ReadLine());
                    Console.Clear();
                }
            }
            catch
            {
                Console.WriteLine("Opção inválida!!!");
            }
        }
    }
}
