﻿namespace conjuntos.Entities
{
    class Instructor
    {
        public string Name { get; set; }
        public int Courses { get; set; }

        public Instructor(string name, int courses)
        {
            Name = name;
            Courses = courses;
        }
    }
}
