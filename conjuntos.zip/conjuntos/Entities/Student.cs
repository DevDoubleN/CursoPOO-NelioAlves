﻿using System;

namespace conjuntos.Entities
{
    class Student
    {
        public int Registration { get; set; }

        public override int GetHashCode()
        {
            return Registration.GetHashCode();
        }

        public override bool Equals(object obj)
        {
            if (!(obj is Student))
                throw new ArgumentException("Student not found!");

            Student other = obj as Student; // Downcasting para manipular o objeto

            return Registration.Equals(other.Registration);
        }
    }
}
