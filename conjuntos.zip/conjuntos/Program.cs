﻿using conjuntos.Entities;
using conjuntos.Entities.Enums;
using System;
using System.Collections.Generic;

namespace conjuntos
{
    class Program
    {
        static void Main(string[] args)
        {
            Instructor instructor = new Instructor("Alex", 3);
            HashSet<Student> students = new HashSet<Student>();

            for (int x = 1; x <= instructor.Courses; x++)
            {
                Console.Write($"How many students for course {Enum.GetName(typeof(ECourses), x)}? ");
                int n = int.Parse(Console.ReadLine());

                for (int y = 0; y < n; y++)
                {
                    students.Add(new Student { Registration = int.Parse(Console.ReadLine()) });
                }
            }

            Console.WriteLine($"Total students: {students.Count}");
        }
    }
}
