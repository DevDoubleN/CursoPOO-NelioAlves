﻿using System;
using System.Globalization;

namespace estrutura_condicional
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Informe qual exercício deseja fazer ou pressione 0 para sair...");
                int exercicioEscolhido = int.Parse(Console.ReadLine());
                Console.Clear();

                while (exercicioEscolhido != 0)
                {
                    switch (exercicioEscolhido)
                    {
                        case 1:
                            // Fazer um programa para ler um número inteiro, e depois dizer se este número é negativo ou não.

                            Console.WriteLine("Digite um número inteiro: ");
                            int valor = int.Parse(Console.ReadLine());

                            if (valor < 0)
                                Console.WriteLine("Negativo!");
                            else
                                Console.WriteLine("Não negativo!");

                            break;
                        case 2:
                            // Fazer um programa para ler um número inteiro e dizer se este número é par ou ímpar.

                            Console.WriteLine("Digite um número: ");
                            int numero = int.Parse(Console.ReadLine());

                            if (numero % 2 == 0)
                                Console.WriteLine("Número par!");
                            else
                                Console.WriteLine("Número ímpar!");

                            break;
                        case 3:
                            // Leia 2 valores inteiros (A e B). Após, o programa deve mostrar uma mensagem "Sao Multiplos" ou "Nao sao 
                            // Multiplos", indicando se os valores lidos são múltiplos entre si. Atenção: os números devem poder ser digitados em 
                            // ordem crescente ou decrescente.

                            Console.WriteLine("Digite dois valores: ");
                            string[] valores = Console.ReadLine().Split(" ");
                            int[] values = new int[valores.Length];
                            for (int x = 0; x < valores.Length; x++)
                                values[x] = int.Parse(valores[x]);

                            if (values[0] < values[1])
                            {
                                int aux = values[0];
                                values[0] = values[1];
                                values[1] = aux;
                            }

                            if (values[0] % values[1] == 0)
                                Console.WriteLine("São múltiplos!");
                            else
                                Console.WriteLine("Não são múltiplos!");

                            break;
                        case 4:
                            // Leia a hora inicial e a hora final de um jogo. A seguir calcule a duração do jogo, sabendo que o mesmo pode 
                            // começar em um dia e terminar em outro, tendo uma duração mínima de 1 hora e máxima de 24 horas.

                            Console.WriteLine("Digite a hora inicial e final do jogo: ");
                            string[] horarios = Console.ReadLine().Split(" ");
                            int[] hrs = new int[horarios.Length];
                            for (int x = 0; x < horarios.Length; x++)
                                hrs[x] = int.Parse(horarios[x]);
                            int totalHrs = 0;

                            if (hrs[0] < hrs[1])
                                totalHrs = hrs[1] - hrs[0];
                            else
                                totalHrs = (24 - hrs[0]) + hrs[1];

                            if (totalHrs < 1 || totalHrs > 24)
                                Console.WriteLine("Os horários informados ultrapassaram a duração mínima ou máxima!");
                            else
                                Console.WriteLine($"O jogo durou {totalHrs} hora(s)");

                            break;
                        case 5:
                            // Com base na tabela de preços, faça um programa que leia o código de um item e a quantidade deste item. A seguir, calcule e
                            // mostre o valor da conta a pagar.

                            Console.WriteLine("******************* TABELA DE PREÇOS ******************* \t");
                            Console.WriteLine("Código \t Especificação \t\t\t\t Preço");
                            Console.WriteLine("1 \t Cachorro-Quente \t\t\t R$ 4.00");
                            Console.WriteLine("2 \t X-Salada \t\t\t\t R$ 4.50");
                            Console.WriteLine("3 \t X-Bacon \t\t\t\t R$ 5.00");
                            Console.WriteLine("4 \t Torrada simples \t\t\t R$ 2.00");
                            Console.WriteLine("5 \t Refrigerante \t\t\t\t R$ 1.50");
                            Console.WriteLine("******************************************************** \t");

                            Console.WriteLine("Escolha o código de um item: ");
                            int codigoItem = int.Parse(Console.ReadLine());
                            Console.WriteLine("Escolha a quantidade: ");
                            int qtdItem = int.Parse(Console.ReadLine());

                            if (codigoItem == 1)
                            {
                                double total = qtdItem * 4.00;
                                Console.WriteLine($"Total: R$ {total.ToString("F2", CultureInfo.InvariantCulture)}");
                            }
                            else if (codigoItem == 2)
                            {
                                double total = qtdItem * 4.50;
                                Console.WriteLine($"Total: R$ {total.ToString("F2", CultureInfo.InvariantCulture)}");
                            }
                            else if (codigoItem == 3)
                            {
                                double total = qtdItem * 5.00;
                                Console.WriteLine($"Total: R$ {total.ToString("F2", CultureInfo.InvariantCulture)}");
                            }
                            else if (codigoItem == 4)
                            {
                                double total = qtdItem * 2.00;
                                Console.WriteLine($"Total: R$ {total.ToString("F2", CultureInfo.InvariantCulture)}");
                            }
                            else if (codigoItem == 5)
                            {
                                double total = qtdItem * 1.50;
                                Console.WriteLine($"Total: R$ {total.ToString("F2", CultureInfo.InvariantCulture)}");
                            }

                            break;
                        case 6:
                            // Você deve fazer um programa que leia um valor qualquer e apresente uma mensagem dizendo em qual dos 
                            // seguintes intervalos([0,25], (25, 50], (50, 75], (75, 100]) este valor se encontra. Obviamente se o valor não estiver em
                            // nenhum destes intervalos, deverá ser impressa a mensagem “Fora de intervalo”.

                            Console.WriteLine("Digite um valor qualquer: ");
                            double valorQualquer = double.Parse(Console.ReadLine());
                            
                            if (valorQualquer >= 0 && valorQualquer <= 25)
                                Console.WriteLine("Intervalo [0, 25]");
                            else if (valorQualquer > 25 && valorQualquer <= 50)
                                Console.WriteLine("Intervalo [25, 50]");
                            else if (valorQualquer > 50 && valorQualquer <= 75)
                                Console.WriteLine("Intervalo [50, 75]");
                            else if (valorQualquer > 75 && valorQualquer <= 100)
                                Console.WriteLine("Intervalo [75, 100]");
                            else
                                Console.WriteLine("Fora do intervalo!");

                            break;
                        case 7:
                            // Leia 2 valores com uma casa decimal(x e y), que devem representar as coordenadas
                            // de um ponto em um plano. A seguir, determine qual o quadrante ao qual pertence o
                            // ponto, ou se está sobre um dos eixos cartesianos ou na origem(x = y = 0).
                            // Se o ponto estiver na origem, escreva a mensagem “Origem”.
                            // Se o ponto estiver sobre um dos eixos escreva “Eixo X” ou “Eixo Y”, conforme for a situação.

                            //              Y
                            //             /\
                            //             ||
                            //     Q2      ||    Q1
                            //             ||
                            // =========================> X
                            //             ||
                            //     Q3      ||    Q4 
                            //             ||

                            Console.WriteLine("Digite o valor de X e Y: ");
                            string[] vlValores = Console.ReadLine().Split(" ");
                            double[] dblVlValores = new double[vlValores.Length];
                            for (int x = 0; x < vlValores.Length; x++)
                                dblVlValores[x] = double.Parse(vlValores[x]);

                            if (dblVlValores[0] == 0 && dblVlValores[1] == 0)
                                Console.WriteLine("Origem!");
                            else if (dblVlValores[0] > 0 && dblVlValores[1] > 0)
                                Console.WriteLine("Q1");
                            else if (dblVlValores[0] < 0 && dblVlValores[1] > 0)
                                Console.WriteLine("Q2");
                            else if (dblVlValores[0] < 0 && dblVlValores[1] < 0)
                                Console.WriteLine("Q3");
                            else if (dblVlValores[0] > 0 && dblVlValores[1] < 0)
                                Console.WriteLine("Q4");

                            break;
                        case 8:
                            // Leia um valor com duas casas decimais, equivalente ao salário de uma pessoa de Lisarb. Em seguida, calcule e 
                            // mostre o valor que esta pessoa deve pagar de Imposto de Renda, segundo a tabela abaixo.
                            // Lembre que, se o salário for R$ 3002.00, a taxa que incide é de 8 % apenas sobre R$ 1000.00, pois a faixa de
                            // salário que fica de R$ 0.00 até R$ 2000.00 é isenta de Imposto de Renda.No exemplo fornecido(abaixo), a taxa é
                            // de 8 % sobre R$ 1000.00 + 18 % sobre R$ 2.00, o que resulta em R$ 80.36 no total.O valor deve ser impresso com
                            // duas casas decimais.

                            Console.WriteLine("Digite o valor do salário: ");
                            double salario = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);
                            double imposto = 0;

                            if (salario <= 2000.0)
                                imposto = 0.0;
                            else if (salario <= 3000.0)
                                imposto = (salario - 2000.0) * 0.08;
                            else if (salario <= 4500.0)
                                imposto = (salario - 3000.0) * 0.18 + 1000.0 * 0.08;
                            else
                                imposto = (salario - 4500.0) * 0.28 + 1500.0 * 0.18 + 1000.0 * 0.08;

                            if (imposto == 0.0)
                                Console.WriteLine("Isento!");
                            else
                                Console.WriteLine("Imposto: R$ " + imposto.ToString("F2", CultureInfo.InvariantCulture));

                            break;
                    }

                    Console.WriteLine("Informe qual exercício deseja fazer ou pressione 0 para sair...");
                    exercicioEscolhido = int.Parse(Console.ReadLine());
                    Console.Clear();
                }
            }
            catch
            {
                Console.WriteLine("Opção inválida!!!");
            }
        }
    }
}
