﻿using System;

namespace pensionato
{
    class Program
    {
        static void Main(string[] args)
        {
            Locatario[] locatarios = new Locatario[10];

            Console.WriteLine("*****************************************************************************************");
            Console.WriteLine("Seja bem-vindo(a)!!!");
            Console.WriteLine("---------------------------");
            Console.WriteLine("1 - Alugar um quarto");
            Console.WriteLine("2 - Listar quartos ocupados/vazios");
            Console.WriteLine("0 - Sair");
            Console.WriteLine("---------------------------");
            Console.Write("Escolha uma opção: ");
            int opcao = int.Parse(Console.ReadLine());

            while (opcao > 0)
            {
                switch (opcao) 
                { 
                    case 1:
                        int quarto = 0;

                        Console.Write("Quantos estudantes vão alugar quarto(s)? ");
                        int qtdEstudantes = int.Parse(Console.ReadLine());

                        if (qtdEstudantes > 0 && qtdEstudantes <= 10)
                        {
                            for(int x = 0; x < qtdEstudantes; x++)
                            {
                                Console.Write("Nome: ");
                                string nome = Console.ReadLine();
                                Console.Write("Email: ");
                                string email = Console.ReadLine();
                                Console.Write("Quarto: ");

                                quarto = int.Parse(Console.ReadLine());

                                while (quarto < 0 || quarto >= 10)
                                {
                                    Console.WriteLine("Quarto inválido! Digite novamente...");
                                    quarto = int.Parse(Console.ReadLine());
                                }

                                locatarios[quarto] = new Locatario();

                                locatarios[quarto].Name = nome;
                                locatarios[quarto].Email = email;
                                locatarios[quarto].Room = quarto;
                                Console.WriteLine("**************");
                            }
                        }

                        Console.WriteLine();
                        Console.WriteLine();
                        Console.WriteLine("Quartos ocupados:");
                        Console.WriteLine();
                        Console.WriteLine();
                        for(int x = 0; x < 10; x++)
                        {
                            if (locatarios[x] != null)
                                Console.WriteLine($"{locatarios[x].Room}: {locatarios[x].Name}, {locatarios[x].Email}");
                        }
                        break;
                    case 2:
                        string ocupados = string.Empty;
                        string vazios = string.Empty;

                        for (int x = 0; x < 10; x++)
                        {
                            if (locatarios[x] == null)
                                vazios += x.ToString() + ",";
                            else
                                ocupados += x.ToString() + ",";
                        }

                        Console.WriteLine("Vazios: " + (string.IsNullOrEmpty(vazios) ? "Nenhum" : vazios.Remove(vazios.Length - 1, 1)));
                        Console.WriteLine("Ocupados: " + (string.IsNullOrEmpty(ocupados) ? "Nenhum" : ocupados.Remove(ocupados.Length - 1, 1)));
                        break;
                    case 0:
                        break;
                    default:
                        Console.WriteLine("Opção inválida!");
                        break;
                }

                Console.WriteLine("*****************************************************************************************");
                Console.WriteLine("Escolha uma opção: ");
                Console.WriteLine("1 - Alugar um quarto");
                Console.WriteLine("2 - Listar quartos ocupados/vazios");
                Console.WriteLine("0 - Sair");

                opcao = int.Parse(Console.ReadLine());
                Console.Clear();
            }

            Console.WriteLine("*****************************************************************************************");
        }
    }
}
