﻿using System;
using System.Globalization;

namespace prova_logica_de_programacao
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Informe qual exercício deseja fazer ou pressione 0 para sair...");
                int exercicioEscolhido = int.Parse(Console.ReadLine());
                Console.Clear();

                while (exercicioEscolhido != 0)
                {
                    switch (exercicioEscolhido)
                    {
                        case 1:
                            // Fazer um programa para ler o código de uma peça 1, o número de peças 1, o valor unitário de cada peça 1, o 
                            // código de uma peça 2, o número de peças 2 e o valor unitário de cada peça 2.Calcule e mostre o valor a ser pago.

                            Console.WriteLine("Digite o código da peça: ");
                            int codigo = int.Parse(Console.ReadLine());
                            Console.WriteLine("Digite a quantidade de peças: ");
                            int quantidade = int.Parse(Console.ReadLine());
                            Console.WriteLine($"Digite o valor unitário de cada peça do código {codigo}: ");
                            double preco = double.Parse(Console.ReadLine());
                            Console.WriteLine("Digite o código da peça: ");
                            int codigo2 = int.Parse(Console.ReadLine());
                            Console.WriteLine("Digite a quantidade de peças: ");
                            int quantidade2 = int.Parse(Console.ReadLine());
                            Console.WriteLine($"Digite o valor unitário de cada peça do código {codigo}: ");
                            double preco2 = double.Parse(Console.ReadLine());
                            double valorTotal = (quantidade * preco) + (quantidade2 * preco2);
                            Console.WriteLine($"Valor a pagar: R$ {valorTotal.ToString("F2")}");

                            break;
                        case 2:
                            // Faça um programa para ler o valor do raio de um círculo, e depois mostrar o valor da área deste círculo com quatro 
                            // casas decimais conforme exemplos.
                            // Fórmula: area = pi * raio²
                            // Considere o valor de π = 3.14159

                            double pi = 3.14159;
                            Console.WriteLine("Digite o valor do raio: ");
                            double raio = double.Parse(Console.ReadLine());
                            double area = pi * Math.Pow(raio, 2);
                            Console.WriteLine($"Área = {area.ToString("F4", CultureInfo.InvariantCulture)}");

                            break;
                        case 3:
                            // Com base na tabela de preços, faça um programa que leia o código de um item e a quantidade deste item. A seguir, calcule e
                            // mostre o valor da conta a pagar.

                            Console.WriteLine("******************* TABELA DE PREÇOS ******************* \t");
                            Console.WriteLine("Código \t Especificação \t\t\t\t Preço");
                            Console.WriteLine("1 \t Cachorro-Quente \t\t\t R$ 4.00");
                            Console.WriteLine("2 \t X-Salada \t\t\t\t R$ 4.50");
                            Console.WriteLine("3 \t X-Bacon \t\t\t\t R$ 5.00");
                            Console.WriteLine("4 \t Torrada simples \t\t\t R$ 2.00");
                            Console.WriteLine("5 \t Refrigerante \t\t\t\t R$ 1.50");
                            Console.WriteLine("******************************************************** \t");

                            Console.WriteLine("Escolha o código de um item: ");
                            int codigoItem = int.Parse(Console.ReadLine());
                            Console.WriteLine("Escolha a quantidade: ");
                            int qtdItem = int.Parse(Console.ReadLine());

                            if (codigoItem == 1)
                            {
                                double total = qtdItem * 4.00;
                                Console.WriteLine($"Total: R$ {total.ToString("F2", CultureInfo.InvariantCulture)}");
                            }
                            else if (codigoItem == 2)
                            {
                                double total = qtdItem * 4.50;
                                Console.WriteLine($"Total: R$ {total.ToString("F2", CultureInfo.InvariantCulture)}");
                            }
                            else if (codigoItem == 3)
                            {
                                double total = qtdItem * 5.00;
                                Console.WriteLine($"Total: R$ {total.ToString("F2", CultureInfo.InvariantCulture)}");
                            }
                            else if (codigoItem == 4)
                            {
                                double total = qtdItem * 2.00;
                                Console.WriteLine($"Total: R$ {total.ToString("F2", CultureInfo.InvariantCulture)}");
                            }
                            else if (codigoItem == 5)
                            {
                                double total = qtdItem * 1.50;
                                Console.WriteLine($"Total: R$ {total.ToString("F2", CultureInfo.InvariantCulture)}");
                            }

                                break;
                        case 4:
                            // Ler os valores dos três coeficientes "a", "b" e "c" de uma equação do segundo grau (ax² + bx + c = 0)
                            // Em seguida, mostrar os valores das raízes da equação, conforme exemplos, usando a fórmula de Baskara.
                            // Se a equação não possuir raízes(o valor de "a" não pode ser zero, e o valor de "delta" não pode ser
                            // negativo), mostrar uma mensagem "Impossivel calcular".

                            double a, b, c, delta, x1, x2;
                            string[] vet = Console.ReadLine().Split(' ');
                            a = double.Parse(vet[0], CultureInfo.InvariantCulture);
                            b = double.Parse(vet[1], CultureInfo.InvariantCulture);
                            c = double.Parse(vet[2], CultureInfo.InvariantCulture);

                            delta = b * b - 4 * a * c;

                            if (a == 0.0 || delta < 0.0)
                            {
                                Console.WriteLine("IMPOSSIVEL CALCULAR");
                            }
                            else
                            {
                                x1 = (-b + Math.Sqrt(delta)) / (2.0 * a);
                                x2 = (-b - Math.Sqrt(delta)) / (2.0 * a);
                                Console.WriteLine("X1 = " + x1.ToString("F5", CultureInfo.InvariantCulture));
                                Console.WriteLine("X2 = " + x2.ToString("F5", CultureInfo.InvariantCulture));
                            }

                            break;
                        case 5:
                            // Escreva um programa que repita a leitura de uma senha até que ela seja válida. Para cada leitura de senha 
                            // incorreta informada, escrever a mensagem "Senha Invalida".Quando a senha for informada corretamente deve ser
                            // impressa a mensagem "Acesso Permitido" e o algoritmo encerrado.Considere que a senha correta é o valor 2002.

                            const string senha = "2002";
                            Console.WriteLine("Digite a senha: ");
                            string senhaDigitada = Console.ReadLine();

                            while (senha != senhaDigitada)
                            {
                                Console.Clear();
                                Console.WriteLine("Senha inválida! Digite Novamente!!!");
                                senhaDigitada = Console.ReadLine();                           
                            }

                            Console.WriteLine("Acesso permitido!!!");

                            break;
                        case 6:
                            // Leia um valor inteiro N.Este valor será a quantidade de valores inteiros X que serão lidos em seguida.
                            // Mostre quantos destes valores X estão dentro do intervalo[10, 20] e quantos estão fora do intervalo, mostrando
                            // essas informações conforme exemplo(use a palavra "in" para dentro do intervalo, e "out" para fora do intervalo).

                            Console.WriteLine("Digite a quantidade de vezes: ");
                            int qtdVezes = int.Parse(Console.ReadLine());
                            int dentro = 0, fora = 0;

                            for (int x = 0; x < qtdVezes; x++)
                            {
                                int valor = int.Parse(Console.ReadLine());

                                if (valor >= 10 && valor <= 20)
                                    dentro++;
                                else
                                    fora++;
                            }

                            Console.WriteLine($"Dentro: {dentro}");
                            Console.WriteLine($"Fora: {fora}");

                            break;
                    }

                    Console.WriteLine("Informe qual exercício deseja fazer ou pressione 0 para sair...");
                    exercicioEscolhido = int.Parse(Console.ReadLine());
                    Console.Clear();
                }
            }
            catch
            {
                Console.WriteLine("Opção inválida!!!");
            }
        }
    }
}
