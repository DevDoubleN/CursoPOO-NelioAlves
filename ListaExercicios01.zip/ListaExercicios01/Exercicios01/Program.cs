﻿using System.Globalization;

namespace Exercicios01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Escolha o exercicio:");
            Console.WriteLine("[1], [2], [3], [4], [5], [6]");
            Console.Write("Opção: ");
            int selectedQuestion = int.Parse(Console.ReadLine());

            try
            {
                if (selectedQuestion < 1 || selectedQuestion > 6)
                {
                    Console.WriteLine("Exercício Inválido!");
                    selectedQuestion = int.Parse(Console.ReadLine());
                }
                if (selectedQuestion == 1)
                {
                    int n1 = int.Parse(Console.ReadLine());
                    int n2 = int.Parse(Console.ReadLine());
                    int soma = n1 + n2;
                    Console.WriteLine("SOMA = " + soma);
                }
                else if (selectedQuestion == 2)
                {
                    double raio = double.Parse(Console.ReadLine());
                    double pi = 3.14159;
                    double area = pi * (Math.Pow(raio, 2));
                    Console.WriteLine(area.ToString("F4", CultureInfo.InvariantCulture));
                }
                else if (selectedQuestion == 3)
                {
                    Console.Write("Valor de A: ");
                    int a = int.Parse(Console.ReadLine());
                    Console.Write("Valor de B: ");
                    int b = int.Parse(Console.ReadLine());
                    Console.Write("Valor de C: ");
                    int c = int.Parse(Console.ReadLine());
                    Console.Write("Valor de D: ");
                    int d = int.Parse(Console.ReadLine());
                    int diferenca = (a * b) - (c * d);
                    Console.WriteLine("Diferença: " + diferenca);
                }
                else if (selectedQuestion == 4)
                {
                    Console.Write("Número: ");
                    int num = int.Parse(Console.ReadLine());
                    Console.Write("Horas Trabalhadas: ");
                    int horas = int.Parse(Console.ReadLine());
                    Console.Write("Salário por hora: ");
                    double salario = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);

                    double totalSalario = salario * horas;

                    Console.WriteLine("Número: " + num);
                    Console.WriteLine("Salário: " + "U" + totalSalario.ToString("c", CultureInfo.CreateSpecificCulture("en-US")));
                    // Formato do total em "c" -> moeda local R$
                }
                else if (selectedQuestion == 5)
                {
                    Console.Write("Código Peça 1: ");
                    int codPeca1 = int.Parse(Console.ReadLine());
                    Console.Write("Quantidade de Peça 1: ");
                    int qtdPeca1 = int.Parse(Console.ReadLine());
                    Console.Write("Valor Unitário Peça 1: ");
                    double valorUnitPeca1 = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture) * qtdPeca1;
                    Console.Write("Código Peça 2: ");
                    int codPeca2 = int.Parse(Console.ReadLine());
                    Console.Write("Quantidade de Peça 2: ");
                    int qtdPeca2 = int.Parse(Console.ReadLine());
                    Console.Write("Valor Unitário Peça 2: ");
                    double valorUnitPeca2 = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture) * qtdPeca2;
                    double total = valorUnitPeca1 + valorUnitPeca2;

                    Console.WriteLine("Valor a pagar: " + total.ToString("c", CultureInfo.InvariantCulture));
                }
                else
                {
                    Console.Write("Valor de A: ");
                    double a = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);
                    Console.Write("Valor de B: ");
                    double b = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);
                    Console.Write("Valor de C: ");
                    double c = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);

                    double rA = a * c / 2;
                    double rB = Math.Pow(c, 2) * 3.14159;
                    double rC = (a + b) * c / 2;
                    double rD = b * 4;
                    double rE = a * b;

                    Console.WriteLine("Triângulo: " + rA.ToString("f3", CultureInfo.InvariantCulture));
                    Console.WriteLine("Círculo: " + rB.ToString("f3", CultureInfo.InvariantCulture));
                    Console.WriteLine("Trapézio: " + rC.ToString("f3", CultureInfo.InvariantCulture));
                    Console.WriteLine("Quadrado: " + rD.ToString("f3", CultureInfo.InvariantCulture));
                    Console.WriteLine("Retângulo: " + rE.ToString("f3", CultureInfo.InvariantCulture));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}