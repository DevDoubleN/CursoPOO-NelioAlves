﻿using System;
using System.Collections.Generic;
using System.Globalization;

namespace listas
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("How many employees will be registered? ");
            int howMany = int.Parse(Console.ReadLine());
            List<Employee> employees = new List<Employee>();

            for(int x = 0; x < howMany; x++)
            {
                Console.WriteLine($"Employee: #{x + 1}");

                Employee employee = new Employee();
                Console.Write("Id: ");
                employee.Id = int.Parse(Console.ReadLine());
                Console.Write("Name: ");
                employee.Name = Console.ReadLine();
                Console.Write("Salary: ");
                employee.Salary = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);
                Console.WriteLine();

                employees.Add(employee);
            }

            Console.WriteLine("");
            Console.Write("Enter the employee Id that will have salary increase: ");
            int id = int.Parse(Console.ReadLine());

            if(employees.Exists(x => x.Id == id))
            {
                Employee emp = employees.Find(x => x.Id == id);
                Console.Write("Enter the percentage: ");
                emp.IncreaseSalary(double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture));
            }
            else
                Console.WriteLine("This Id doesn't exist!");

            Console.WriteLine();
            Console.WriteLine("Updated list of employees:");

            foreach(var employee in employees)
            {
                Console.WriteLine(employee);
            }
        }
    }
}
