﻿using System;
using System.IO;

namespace arquivos
{
    class arquivos_3
    {
        public void Execute()
        {
            string sourcePath = @"";
            StreamReader sr = null;

            try
            {
                Console.Clear();
                Console.WriteLine("Selecionado: 3 - Bloco 'Using'");
                Console.WriteLine("Utilizando bloco using para controle da instância, encerrando a mesma ao final do bloco.");

                using (sr = File.OpenText(sourcePath))
                {
                    while (!sr.EndOfStream)
                        Console.WriteLine(sr.ReadLine());
                }
            }
            catch (IOException ex)
            {
                Console.WriteLine("An error occurred");
                Console.WriteLine(ex.Message);
            }
        }
    }
}
