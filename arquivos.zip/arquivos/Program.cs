﻿using System;
using System.IO;
using System.Globalization;

namespace arquivos
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                string opcao = "";

                Console.WriteLine("*** Selecione uma atividade: ***");
                Console.WriteLine("1 - File e FileInfo");
                Console.WriteLine("2 - FileStream e StreamReader");
                Console.WriteLine("3 - Bloco 'Using'");
                Console.WriteLine("4 - StreamWriter");
                Console.WriteLine("5 - Teste final");
                Console.WriteLine("9 - Sair");

                Console.WriteLine();
                opcao = Console.ReadLine();

                while (opcao != "9")
                {
                    switch (opcao)
                    {
                        case "1":
                            arquivos_1 arq1 = new arquivos_1();
                            arq1.Execute();

                            break;
                        case "2":
                            arquivos_2 arq2 = new arquivos_2();
                            arq2.Execute();

                            break;
                        case "3":
                            arquivos_3 arq3 = new arquivos_3();
                            arq3.Execute();

                            break;
                        case "4":
                            arquivos_4 arq4 = new arquivos_4();
                            arq4.Execute();

                            break;
                        case "5":
                            arquivos_5 arq5 = new arquivos_5();
                            arq5.Execute();

                            break;
                        default:
                            Console.Clear();
                            Console.WriteLine("Valor inválido, selecione novamente...");
                            break;
                    }

                    Console.Clear();
                    Console.WriteLine("1 - File e FileInfo");
                    Console.WriteLine("2 - FileStream e StreamReader");
                    Console.WriteLine("3 - Bloco 'Using'");
                    Console.WriteLine("4 - StreamWriter");
                    Console.WriteLine("9 - Sair");
                    opcao = Console.ReadLine();
                }
            }
            catch (IOException ex)
            {
                Console.Clear();
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.Clear();
                Console.WriteLine("An error occurred...");
                Console.WriteLine(ex.Message);
            }
        }
    }
}
