﻿using System;
using System.IO;

namespace arquivos
{
    class arquivos_2
    {
        public void Execute()
        {
            string sourcePath = @"";
            FileStream fs = null;
            StreamReader sr = null;

            try
            {
                Console.Clear();
                Console.WriteLine("Selecionado: 2 - FileStream e StreamReader");
                Console.WriteLine("Utilizando FileStream que disponibiliza uma stream associada a um arquivo, permitindo operações de leitura e escrita.");
                Console.WriteLine("E também StreamReader que é capaz de ler caractéres a partir de uma stream binária. (Ex.: FileStream)");

                fs = new FileStream(sourcePath, FileMode.Open);
                sr = new StreamReader(fs);
                string lines = sr.ReadToEnd();

                Console.WriteLine(lines);
            }
            catch (IOException ex)
            {
                Console.WriteLine("An error occurred");
                Console.WriteLine(ex.Message);
            }
            finally
            {
                if (sr != null) sr.Close();
                if (fs != null) fs.Close();
            }
        }
    }
}
