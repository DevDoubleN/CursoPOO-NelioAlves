﻿using System;
using System.IO;

namespace arquivos
{
    class arquivos_1
    {
        public void Execute()
        {
            string sourcePath = @"";
            string targetPath = @"";

            try
            {
                Console.Clear();
                Console.WriteLine("Selecionado: 1 - File e FileInfo");
                Console.WriteLine("Utilizando File (classe simples com métodos estáticos, não precisa de instância, porém realiza verificação de segurança a cada execução, se tornando mais lento).");
                Console.WriteLine("Já a FileInfo é mais rápida, porém precisa de instância");
                                
                FileInfo fileInfo = new FileInfo(sourcePath);
                string[] lines = File.ReadAllLines(sourcePath);

                fileInfo.CopyTo(targetPath);
                Console.WriteLine($"\nArquivo copiado para: {targetPath}");

                Console.WriteLine("\nLendo o arquivo... \n\n");
                foreach (var line in lines)
                    Console.WriteLine(line);
            }
            catch (IOException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
