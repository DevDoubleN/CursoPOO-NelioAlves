﻿using System;
using System.Globalization;
using System.IO;

namespace arquivos
{
    class arquivos_5
    {
        public void Execute()
        {
            string directorySourcePath = @"";
            string sourcePath = directorySourcePath + @"\order.txt";
            string directoryTargetPath = directorySourcePath + @"\out";
            string targetPath = directorySourcePath + @"\out\summary.txt";
            StreamReader sr = null;
            StreamWriter sw = null;

            try
            {
                Console.Clear();
                Console.WriteLine();

                //  Fazer um programa para ler o caminho de um arquivo contendo os dados de itens vendidos. Cada item possui um nome, preço unitário e quantidade, separados por vírgula.
                //  Você deve gerar um novo arquivo chamado "summary", localizado em uma subpasta chamada "out" a partir da pasta original do arquivo de origem, contendo apenas o nome e o valor total para aquele item (preço unitário multiplicado pela quantidade).

                Directory.CreateDirectory(directoryTargetPath);

                using (sr = File.OpenText(sourcePath))
                {
                    using (sw = File.AppendText(targetPath))
                    {
                        while (!sr.EndOfStream)
                        {
                            string[] lineContent = sr.ReadLine().Split(",");

                            double value = double.Parse(lineContent[1].Replace(".", ",")) * double.Parse(lineContent[2].Replace(".", ","));

                            sw.WriteLine(lineContent[0] + ", \t\t R$ " + value.ToString("F2", CultureInfo.InvariantCulture));
                        }
                    }
                }
            }
            catch (IOException ex)
            {
                Console.WriteLine("An error occurred");
                Console.WriteLine(ex.Message);
            }
        }
    }
}
