﻿using System;
using System.IO;

namespace arquivos
{
    class arquivos_4
    {
        public void Execute()
        {
            string sourcePath = @"";
            string targetPath = @"";

            try
            {
                Console.Clear();
                Console.WriteLine("4 - StreamWriter");
                Console.WriteLine("Utilizando para escrever no arquivo stream");

                string[] lines = File.ReadAllLines(sourcePath);

                using (StreamWriter sw = File.AppendText(targetPath))
                {
                    foreach (string line in lines)
                        sw.WriteLine(line.ToUpper());
                }
            }
            catch (IOException ex)
            {
                Console.WriteLine("An error occurred");
                Console.WriteLine(ex.Message);
            }
        }
    }
}
