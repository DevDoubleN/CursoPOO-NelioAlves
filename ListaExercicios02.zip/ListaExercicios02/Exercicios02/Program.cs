﻿
namespace Exercicios02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Escolha o exercicio:");
            Console.WriteLine("[1], [2], [3], [4], [5], [6], [7], [8]");
            Console.Write("Opção: ");
            int selectedQuestion = int.Parse(Console.ReadLine());

            try
            {
                if (selectedQuestion < 1 || selectedQuestion > 8)
                {
                    Console.WriteLine("Exercício Inválido!");
                    selectedQuestion = int.Parse(Console.ReadLine());
                }
                if (selectedQuestion == 1)
                {
                    Console.Write("Digite um número inteiro: ");
                    int num = int.Parse(Console.ReadLine());
                    if (num < 0)
                        Console.WriteLine("NEGATIVO!");
                    else
                        Console.WriteLine("NÃO POSITIVO!");
                }
                else if (selectedQuestion == 2)
                {
                    Console.Write("Digite um número inteiro: ");
                    int num = int.Parse(Console.ReadLine());
                    if (num %2 == 0)
                        Console.WriteLine("PAR!");
                    else
                        Console.WriteLine("ÍMPAR!");
                }
                else if (selectedQuestion == 3)
                {
                    Console.Write("Digite o valor de A: ");
                    int a = int.Parse(Console.ReadLine());
                    Console.Write("Digite o valor de B: ");
                    int b = int.Parse(Console.ReadLine());
                    if (a % b == 0 || b % a == 0)
                        Console.WriteLine("SÃO MÚLTIPLOS!");
                    else
                        Console.WriteLine("NÃO SÃO MÚLTIPLOS");
                }
                else if (selectedQuestion == 4)
                {
                    Console.Write("Digite a hora inicial: ");
                    int horaInicial = int.Parse(Console.ReadLine());
                    Console.Write("Digite a hora final: ");
                    int horaFinal = int.Parse(Console.ReadLine());

                    if (horaInicial > 12)
                    {
                        int x = 24 - horaInicial;

                        Console.WriteLine("O JOGO DUROU {0} HORAS", x + horaFinal);

                    }
                    else if (horaFinal - horaInicial == 0)
                    {
                        Console.WriteLine("O JOGO DUROU 24 HORAS");
                    }
                    else
                    {
                        Console.WriteLine("O JOGO DUROU {0} HORAS", horaFinal - horaInicial);
                    }

                }
                else if (selectedQuestion == 5)
                {
                    Console.WriteLine("CÓDIGO \t ESPECIFICAÇÃO \t PREÇO");
                    Console.WriteLine("1 \t Cachorro-Quente R$4.00");
                    Console.WriteLine("2 \t X-Salada \t R$4.50");
                    Console.WriteLine("3 \t X-Bacon \t R$5.00");
                    Console.WriteLine("4 \t Torrada Simples R$2.00");
                    Console.WriteLine("5 \t Refrigerante \t R$1.50");
                    Console.Write("Escolha um item: ");
                    int codigo = int.Parse(Console.ReadLine());
                    Console.Write("Escolha a quantidade: ");
                    int quantidade = int.Parse(Console.ReadLine());

                    if (codigo > 0 && codigo <= 5)
                    {
                        if (codigo == 1)
                        {
                            double total = quantidade * 4;

                            Console.WriteLine("Total: R${0}", total);
                        }
                        else if (codigo == 2)
                        {
                            double total = quantidade * 4.5;

                            Console.WriteLine("Total: R${0}", total);
                        }
                        else if (codigo == 3)
                        {
                            double total = quantidade * 5;

                            Console.WriteLine("Total: R${0}", total);

                        }
                        else if (codigo == 4)
                        {
                            double total = quantidade * 2;

                            Console.WriteLine("Total: R${0}", total);
                        }
                        else if (codigo == 5)
                        {
                            double total = quantidade * 1.5;

                            Console.WriteLine("Total: R${0}", total);
                        }
                    }
                    else
                    {
                        Console.Write("Item Inválido! Escolha outro item: ");
                        codigo = int.Parse(Console.ReadLine());
                    }
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}