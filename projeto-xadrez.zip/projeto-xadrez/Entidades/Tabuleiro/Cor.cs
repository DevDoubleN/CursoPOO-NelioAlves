﻿namespace projeto_xadrez.Entidades.Tabuleiro
{
    enum Cor
    {
        Branca,
        Preta,
        Amarela,
        Azul,
        Vermelha,
        Verde,
        Laranja
    }
}
