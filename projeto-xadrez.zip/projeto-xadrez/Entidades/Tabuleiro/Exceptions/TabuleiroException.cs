﻿using System;

namespace projeto_xadrez.Entidades.Tabuleiro.Exceptions
{
    class TabuleiroException : ApplicationException
    {
        public TabuleiroException(string msg) : base(msg)
        {
        }
    }
}
