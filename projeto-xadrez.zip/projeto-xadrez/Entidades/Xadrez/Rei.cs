﻿using projeto_xadrez.Entidades.Tabuleiro;

namespace projeto_xadrez.Entidades.Xadrez
{
    class Rei : Peca
    {
        private PartidaXadrez _Partida;

        public Rei(Tabuleiro.Tabuleiro tabuleiro, Cor cor, PartidaXadrez partida) : base(tabuleiro, cor)
        {
            _Partida = partida;
        }

        public bool PodeMover(Posicao posicao)
        {
            Peca peca = base.Tabuleiro.Peca(posicao);

            return peca == null || peca.Cor != Cor;
        }

        private bool TesteTorreParaRoque(Posicao posicao)
        {
            Peca peca = Tabuleiro.Peca(posicao);

            return peca != null && peca is Torre && peca.Cor == Cor && peca.QtdMovimentos == 0;
        }

        public override bool[,] MovimentosPossiveis()
        {
            bool[,] matriz = new bool[base.Tabuleiro.Linhas, base.Tabuleiro.Colunas];

            Posicao posicao = new Posicao(0, 0);
            
            posicao.DefinirValores(base.Posicao.Linha - 1, base.Posicao.Coluna);

            if (base.Tabuleiro.PosicaoValida(posicao) && PodeMover(posicao))
                matriz[posicao.Linha, posicao.Coluna] = true;

            posicao.DefinirValores(base.Posicao.Linha - 1, base.Posicao.Coluna + 1);

            if (base.Tabuleiro.PosicaoValida(posicao) && PodeMover(posicao))
                matriz[posicao.Linha, posicao.Coluna] = true;

            posicao.DefinirValores(base.Posicao.Linha, base.Posicao.Coluna + 1);

            if (base.Tabuleiro.PosicaoValida(posicao) && PodeMover(posicao))
                matriz[posicao.Linha, posicao.Coluna] = true;

            posicao.DefinirValores(base.Posicao.Linha + 1, base.Posicao.Coluna + 1);

            if (base.Tabuleiro.PosicaoValida(posicao) && PodeMover(posicao))
                matriz[posicao.Linha, posicao.Coluna] = true;

            posicao.DefinirValores(base.Posicao.Linha + 1, base.Posicao.Coluna);

            if (base.Tabuleiro.PosicaoValida(posicao) && PodeMover(posicao))
                matriz[posicao.Linha, posicao.Coluna] = true;

            posicao.DefinirValores(base.Posicao.Linha + 1, base.Posicao.Coluna - 1);

            if (base.Tabuleiro.PosicaoValida(posicao) && PodeMover(posicao))
                matriz[posicao.Linha, posicao.Coluna] = true;

            posicao.DefinirValores(base.Posicao.Linha, base.Posicao.Coluna - 1);

            if (base.Tabuleiro.PosicaoValida(posicao) && PodeMover(posicao))
                matriz[posicao.Linha, posicao.Coluna] = true;

            posicao.DefinirValores(base.Posicao.Linha - 1, base.Posicao.Coluna - 1);

            if (base.Tabuleiro.PosicaoValida(posicao) && PodeMover(posicao))
                matriz[posicao.Linha, posicao.Coluna] = true;

            // Roque
            if (QtdMovimentos == 0 && !_Partida.Xeque)
            {
                // Roque pequeno
                Posicao posicaoTorre = new Posicao(base.Posicao.Linha, base.Posicao.Coluna + 3);

                if (TesteTorreParaRoque(posicaoTorre))
                {
                    Posicao p1 = new Posicao(base.Posicao.Linha, base.Posicao.Coluna + 1);
                    Posicao p2 = new Posicao(base.Posicao.Linha, base.Posicao.Coluna + 2);

                    if (Tabuleiro.Peca(p1) == null && Tabuleiro.Peca(p2) == null)
                        matriz[base.Posicao.Linha, base.Posicao.Coluna + 2] = true;
                }

                // Roque grande
                Posicao posicaoTorre2 = new Posicao(base.Posicao.Linha, base.Posicao.Coluna - 4);

                if (TesteTorreParaRoque(posicaoTorre2))
                {
                    Posicao p1 = new Posicao(base.Posicao.Linha, base.Posicao.Coluna - 1);
                    Posicao p2 = new Posicao(base.Posicao.Linha, base.Posicao.Coluna - 2);
                    Posicao p3 = new Posicao(base.Posicao.Linha, base.Posicao.Coluna - 3);

                    if (Tabuleiro.Peca(p1) == null && Tabuleiro.Peca(p2) == null && Tabuleiro.Peca(p3) == null)
                        matriz[base.Posicao.Linha, base.Posicao.Coluna - 2] = true;
                }
            }

            return matriz;
        }

        public override string ToString()
        {
            return "R";
        }
    }
}
