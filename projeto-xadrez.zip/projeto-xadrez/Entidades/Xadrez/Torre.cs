﻿using projeto_xadrez.Entidades.Tabuleiro;

namespace projeto_xadrez.Entidades.Xadrez
{
    class Torre : Peca
    {
        public Torre(Tabuleiro.Tabuleiro tabuleiro, Cor cor) : base(tabuleiro, cor)
        {
        }

        public bool PodeMover(Posicao posicao)
        {
            Peca peca = base.Tabuleiro.Peca(posicao);

            return peca == null || peca.Cor != Cor;
        }

        public override bool[,] MovimentosPossiveis()
        {
            bool[,] matriz = new bool[base.Tabuleiro.Linhas, base.Tabuleiro.Colunas];

            Posicao posicao = new Posicao(0, 0);

            posicao.DefinirValores(base.Posicao.Linha - 1, base.Posicao.Coluna);

            while(base.Tabuleiro.PosicaoValida(posicao) && PodeMover(posicao))
            {
                matriz[posicao.Linha, posicao.Coluna] = true;

                if (base.Tabuleiro.Peca(posicao) != null && base.Tabuleiro.Peca(posicao).Cor != Cor)
                    break;

                posicao.Linha = posicao.Linha - 1;
            }

            posicao.DefinirValores(base.Posicao.Linha + 1, base.Posicao.Coluna);

            while (base.Tabuleiro.PosicaoValida(posicao) && PodeMover(posicao))
            {
                matriz[posicao.Linha, posicao.Coluna] = true;

                if (base.Tabuleiro.Peca(posicao) != null && base.Tabuleiro.Peca(posicao).Cor != Cor)
                    break;
                
                posicao.Linha = posicao.Linha + 1;
            }

            posicao.DefinirValores(base.Posicao.Linha, base.Posicao.Coluna + 1);

            while (base.Tabuleiro.PosicaoValida(posicao) && PodeMover(posicao))
            {
                matriz[posicao.Linha, posicao.Coluna] = true;

                if (base.Tabuleiro.Peca(posicao) != null && base.Tabuleiro.Peca(posicao).Cor != Cor)
                    break;
                
                posicao.Coluna = posicao.Coluna + 1;
            }

            posicao.DefinirValores(base.Posicao.Linha, base.Posicao.Coluna - 1);

            while (base.Tabuleiro.PosicaoValida(posicao) && PodeMover(posicao))
            {
                matriz[posicao.Linha, posicao.Coluna] = true;

                if (base.Tabuleiro.Peca(posicao) != null && base.Tabuleiro.Peca(posicao).Cor != Cor)
                    break;
                
                posicao.Coluna = posicao.Coluna - 1;
            }

            return matriz;
        }

        public override string ToString()
        {
            return "T";
        }
    }
}
