﻿using projeto_xadrez.Entidades.Tabuleiro;

namespace projeto_xadrez.Entidades.Xadrez
{
    class Bispo : Peca
    {
        public Bispo(Tabuleiro.Tabuleiro tabuleiro, Cor cor) : base (tabuleiro, cor)
        {
        }

        public override string ToString()
        {
            return "B";
        }

        private bool PodeMover(Posicao posicao)
        {
            Peca peca = base.Tabuleiro.Peca(posicao);

            return peca == null || peca.Cor != Cor;
        }

        public override bool[,] MovimentosPossiveis()
        {
            bool[,] matriz = new bool[base.Tabuleiro.Linhas, base.Tabuleiro.Colunas];

            Posicao posicao = new Posicao(0, 0);

            posicao.DefinirValores(base.Posicao.Linha - 1, base.Posicao.Coluna - 1);
            while (base.Tabuleiro.PosicaoValida(posicao) && PodeMover(posicao))
            {
                matriz[posicao.Linha, posicao.Coluna] = true;

                if (base.Tabuleiro.Peca(posicao) != null && base.Tabuleiro.Peca(posicao).Cor != Cor)
                    break;

                posicao.DefinirValores(posicao.Linha - 1, posicao.Coluna - 1);
            }

            posicao.DefinirValores(base.Posicao.Linha - 1, base.Posicao.Coluna + 1);
            while (base.Tabuleiro.PosicaoValida(posicao) && PodeMover(posicao))
            {
                matriz[posicao.Linha, posicao.Coluna] = true;

                if (base.Tabuleiro.Peca(posicao) != null && base.Tabuleiro.Peca(posicao).Cor != Cor)
                    break;

                posicao.DefinirValores(posicao.Linha - 1, posicao.Coluna + 1);
            }

            posicao.DefinirValores(base.Posicao.Linha + 1, base.Posicao.Coluna + 1);
            while (base.Tabuleiro.PosicaoValida(posicao) && PodeMover(posicao))
            {
                matriz[posicao.Linha, posicao.Coluna] = true;

                if (base.Tabuleiro.Peca(posicao) != null && base.Tabuleiro.Peca(posicao).Cor != Cor)
                    break;

                posicao.DefinirValores(posicao.Linha + 1, posicao.Coluna + 1);
            }

            posicao.DefinirValores(base.Posicao.Linha + 1, base.Posicao.Coluna - 1);
            while (base.Tabuleiro.PosicaoValida(posicao) && PodeMover(posicao))
            {
                matriz[posicao.Linha, posicao.Coluna] = true;

                if (base.Tabuleiro.Peca(posicao) != null && base.Tabuleiro.Peca(posicao).Cor != Cor)
                    break;

                posicao.DefinirValores(posicao.Linha + 1, posicao.Coluna - 1);
            }

            return matriz;
        }
    }
}
