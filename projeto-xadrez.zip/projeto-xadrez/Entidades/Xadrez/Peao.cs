﻿using projeto_xadrez.Entidades.Tabuleiro;

namespace projeto_xadrez.Entidades.Xadrez
{
    class Peao : Peca
    {
        private PartidaXadrez _Partida;

        public Peao(Tabuleiro.Tabuleiro tabuleiro, Cor cor, PartidaXadrez partida) : base (tabuleiro, cor)
        {
            _Partida = partida;
        }

        public override string ToString()
        {
            return "P";
        }

        private bool ExisteInimigo(Posicao posicao)
        {
            Peca peca = Tabuleiro.Peca(posicao);

            return peca != null && peca.Cor != Cor;
        }

        private bool Livre(Posicao posicao)
        {
            return Tabuleiro.Peca(posicao) == null;
        }

        public override bool[,] MovimentosPossiveis()
        {
            bool[,] matriz = new bool[Tabuleiro.Linhas, Tabuleiro.Colunas];

            Posicao posicao = new Posicao(0, 0);

            if (Cor == Cor.Branca)
            {
                posicao.DefinirValores(base.Posicao.Linha - 1, base.Posicao.Coluna);
                if (Tabuleiro.PosicaoValida(posicao) && Livre(posicao))
                    matriz[posicao.Linha, posicao.Coluna] = true;

                posicao.DefinirValores(base.Posicao.Linha - 2, base.Posicao.Coluna);
                if (Tabuleiro.PosicaoValida(posicao) && Livre(posicao) && QtdMovimentos == 0)
                    matriz[posicao.Linha, posicao.Coluna] = true;

                posicao.DefinirValores(base.Posicao.Linha - 1, base.Posicao.Coluna - 1);
                if (Tabuleiro.PosicaoValida(posicao) && ExisteInimigo(posicao))
                    matriz[posicao.Linha, posicao.Coluna] = true;

                posicao.DefinirValores(base.Posicao.Linha - 1, base.Posicao.Coluna + 1);
                if (Tabuleiro.PosicaoValida(posicao) && ExisteInimigo(posicao))
                    matriz[posicao.Linha, posicao.Coluna] = true;

                // En Passant
                if (base.Posicao.Linha == 3)
                {
                    Posicao esquerda = new Posicao(base.Posicao.Linha, base.Posicao.Coluna - 1);

                    if (base.Tabuleiro.PosicaoValida(esquerda) && ExisteInimigo(esquerda) && base.Tabuleiro.Peca(esquerda) == _Partida._VulneravelEnPassant)
                    {
                        matriz[esquerda.Linha - 1, esquerda.Coluna] = true;
                    }

                    Posicao direita = new Posicao(base.Posicao.Linha, base.Posicao.Coluna + 1);

                    if (base.Tabuleiro.PosicaoValida(direita) && ExisteInimigo(direita) && base.Tabuleiro.Peca(direita) == _Partida._VulneravelEnPassant)
                    {
                        matriz[direita.Linha - 1, direita.Coluna] = true;
                    }
                }
            }
            else
            {
                posicao.DefinirValores(base.Posicao.Linha + 1, base.Posicao.Coluna);
                if (Tabuleiro.PosicaoValida(posicao) && Livre(posicao))
                    matriz[posicao.Linha, posicao.Coluna] = true;

                posicao.DefinirValores(base.Posicao.Linha + 2, base.Posicao.Coluna);
                if (Tabuleiro.PosicaoValida(posicao) && Livre(posicao) && QtdMovimentos == 0)
                    matriz[posicao.Linha, posicao.Coluna] = true;

                posicao.DefinirValores(base.Posicao.Linha + 1, base.Posicao.Coluna - 1);
                if (Tabuleiro.PosicaoValida(posicao) && ExisteInimigo(posicao))
                    matriz[posicao.Linha, posicao.Coluna] = true;

                posicao.DefinirValores(base.Posicao.Linha + 1, base.Posicao.Coluna + 1);
                if (Tabuleiro.PosicaoValida(posicao) && ExisteInimigo(posicao))
                    matriz[posicao.Linha, posicao.Coluna] = true;

                // En Passant
                if (base.Posicao.Linha == 4)
                {
                    Posicao esquerda = new Posicao(base.Posicao.Linha, base.Posicao.Coluna - 1);

                    if (base.Tabuleiro.PosicaoValida(esquerda) && ExisteInimigo(esquerda) && base.Tabuleiro.Peca(esquerda) == _Partida._VulneravelEnPassant)
                    {
                        matriz[esquerda.Linha + 1, esquerda.Coluna] = true;
                    }

                    Posicao direita = new Posicao(base.Posicao.Linha, base.Posicao.Coluna + 1);

                    if (base.Tabuleiro.PosicaoValida(direita) && ExisteInimigo(direita) && base.Tabuleiro.Peca(direita) == _Partida._VulneravelEnPassant)
                    {
                        matriz[direita.Linha + 1, direita.Coluna] = true;
                    }
                }
            }

            return matriz;
        }
    }
}
