﻿using projeto_xadrez.Entidades.Tabuleiro;

namespace projeto_xadrez.Entidades.Xadrez
{
    class Dama : Peca
    {
        public Dama(Tabuleiro.Tabuleiro tabuleiro, Cor cor) : base (tabuleiro, cor)
        {
        }

        public override string ToString()
        {
            return "D";
        }

        private bool PodeMover(Posicao posicao)
        {
            Peca peca = base.Tabuleiro.Peca(posicao);

            return peca == null || peca.Cor != Cor;
        }

        public override bool[,] MovimentosPossiveis()
        {
            bool[,] matriz = new bool[Tabuleiro.Linhas, Tabuleiro.Colunas];

            Posicao posicao = new Posicao(0, 0);

            posicao.DefinirValores(base.Posicao.Linha, base.Posicao.Coluna - 1);
            while (Tabuleiro.PosicaoValida(posicao) && PodeMover(posicao))
            {
                matriz[posicao.Linha, posicao.Coluna] = true;

                if (Tabuleiro.Peca(posicao) != null && Tabuleiro.Peca(posicao).Cor != Cor)
                    break;

                posicao.DefinirValores(posicao.Linha, posicao.Coluna - 1);
            }

            posicao.DefinirValores(base.Posicao.Linha, base.Posicao.Coluna + 1);
            while (Tabuleiro.PosicaoValida(posicao) && PodeMover(posicao))
            {
                matriz[posicao.Linha, posicao.Coluna] = true;

                if (Tabuleiro.Peca(posicao) != null && Tabuleiro.Peca(posicao).Cor != Cor)
                    break;

                posicao.DefinirValores(posicao.Linha, posicao.Coluna + 1);
            }

            posicao.DefinirValores(base.Posicao.Linha - 1, base.Posicao.Coluna);
            while (Tabuleiro.PosicaoValida(posicao) && PodeMover(posicao))
            {
                matriz[posicao.Linha, posicao.Coluna] = true;

                if (Tabuleiro.Peca(posicao) != null && Tabuleiro.Peca(posicao).Cor != Cor)
                    break;

                posicao.DefinirValores(posicao.Linha - 1, posicao.Coluna);
            }

            posicao.DefinirValores(base.Posicao.Linha + 1, base.Posicao.Coluna);
            while (Tabuleiro.PosicaoValida(posicao) && PodeMover(posicao))
            {
                matriz[posicao.Linha, posicao.Coluna] = true;

                if (Tabuleiro.Peca(posicao) != null && Tabuleiro.Peca(posicao).Cor != Cor)
                    break;

                posicao.DefinirValores(posicao.Linha + 1, posicao.Coluna);
            }

            posicao.DefinirValores(base.Posicao.Linha - 1, base.Posicao.Coluna - 1);
            while (Tabuleiro.PosicaoValida(posicao) && PodeMover(posicao))
            {
                matriz[posicao.Linha, posicao.Coluna] = true;

                if (Tabuleiro.Peca(posicao) != null && Tabuleiro.Peca(posicao).Cor != Cor)
                    break;

                posicao.DefinirValores(posicao.Linha - 1, posicao.Coluna - 1);
            }

            posicao.DefinirValores(base.Posicao.Linha - 1, base.Posicao.Coluna + 1);
            while (Tabuleiro.PosicaoValida(posicao) && PodeMover(posicao))
            {
                matriz[posicao.Linha, posicao.Coluna] = true;

                if (Tabuleiro.Peca(posicao) != null && Tabuleiro.Peca(posicao).Cor != Cor)
                    break;

                posicao.DefinirValores(posicao.Linha - 1, posicao.Coluna + 1);
            }

            posicao.DefinirValores(base.Posicao.Linha + 1, base.Posicao.Coluna + 1);
            while (Tabuleiro.PosicaoValida(posicao) && PodeMover(posicao))
            {
                matriz[posicao.Linha, posicao.Coluna] = true;

                if (Tabuleiro.Peca(posicao) != null && Tabuleiro.Peca(posicao).Cor != Cor)
                    break;

                posicao.DefinirValores(posicao.Linha + 1, posicao.Coluna + 1);
            }

            posicao.DefinirValores(base.Posicao.Linha + 1, base.Posicao.Coluna - 1);
            while (Tabuleiro.PosicaoValida(posicao) && PodeMover(posicao))
            {
                matriz[posicao.Linha, posicao.Coluna] = true;

                if (Tabuleiro.Peca(posicao) != null && Tabuleiro.Peca(posicao).Cor != Cor)
                    break;

                posicao.DefinirValores(posicao.Linha + 1, posicao.Coluna - 1);
            }

            return matriz;
        }
    }
}
