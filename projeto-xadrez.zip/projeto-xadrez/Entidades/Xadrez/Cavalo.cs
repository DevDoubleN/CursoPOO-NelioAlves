﻿using projeto_xadrez.Entidades.Tabuleiro;

namespace projeto_xadrez.Entidades.Xadrez
{
    class Cavalo : Peca
    {
        public Cavalo(Tabuleiro.Tabuleiro tabuleiro, Cor cor) : base (tabuleiro, cor)
        {
        }

        public override string ToString()
        {
            return "C";
        }

        private bool PodeMover(Posicao posicao)
        {
            Peca peca = base.Tabuleiro.Peca(posicao);

            return peca == null || peca.Cor != Cor;
        }

        public override bool[,] MovimentosPossiveis()
        {
            bool[,] matriz = new bool[base.Tabuleiro.Linhas, base.Tabuleiro.Colunas];

            Posicao posicao = new Posicao(0, 0);

            posicao.DefinirValores(base.Posicao.Linha - 1, base.Posicao.Coluna - 2);
            if (base.Tabuleiro.PosicaoValida(posicao) && PodeMover(posicao))
                matriz[posicao.Linha, posicao.Coluna] = true;

            posicao.DefinirValores(base.Posicao.Linha - 2, base.Posicao.Coluna - 1);
            if (base.Tabuleiro.PosicaoValida(posicao) && PodeMover(posicao))
                matriz[posicao.Linha, posicao.Coluna] = true;

            posicao.DefinirValores(base.Posicao.Linha - 2, base.Posicao.Coluna + 1);
            if (base.Tabuleiro.PosicaoValida(posicao) && PodeMover(posicao))
                matriz[posicao.Linha, posicao.Coluna] = true;

            posicao.DefinirValores(base.Posicao.Linha - 1, base.Posicao.Coluna + 2);
            if (base.Tabuleiro.PosicaoValida(posicao) && PodeMover(posicao))
                matriz[posicao.Linha, posicao.Coluna] = true;

            posicao.DefinirValores(base.Posicao.Linha + 1, base.Posicao.Coluna + 2);
            if (base.Tabuleiro.PosicaoValida(posicao) && PodeMover(posicao))
                matriz[posicao.Linha, posicao.Coluna] = true;

            posicao.DefinirValores(base.Posicao.Linha + 2, base.Posicao.Coluna + 1);
            if (base.Tabuleiro.PosicaoValida(posicao) && PodeMover(posicao))
                matriz[posicao.Linha, posicao.Coluna] = true;

            posicao.DefinirValores(base.Posicao.Linha + 2, base.Posicao.Coluna - 1);
            if (base.Tabuleiro.PosicaoValida(posicao) && PodeMover(posicao))
                matriz[posicao.Linha, posicao.Coluna] = true;

            posicao.DefinirValores(base.Posicao.Linha + 1, base.Posicao.Coluna - 2);
            if (base.Tabuleiro.PosicaoValida(posicao) && PodeMover(posicao))
                matriz[posicao.Linha, posicao.Coluna] = true;

            return matriz;
        }
    }
}
