﻿using comparable.Entities;
using System;
using System.Collections.Generic;
using System.IO;

namespace comparable
{
    class Program
    {
        static void Main(string[] args)
        {
            string path = @"";

            try
            {
                using (StreamReader sr = new StreamReader(path))
                {
                    List<Employee> employees = new List<Employee>();
                    while (!sr.EndOfStream)
                    {
                        employees.Add(new Employee(sr.ReadLine()));
                    }
                    employees.Sort();
                    foreach(Employee employee in employees)
                        Console.WriteLine(employee);
                }
            }
            catch(IOException ex)
            {
                Console.WriteLine("An error occurred");
                Console.WriteLine(ex.Message);
            }
        }
    }
}
