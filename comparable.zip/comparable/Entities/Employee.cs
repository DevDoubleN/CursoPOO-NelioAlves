﻿using System;
using System.Globalization;

namespace comparable.Entities
{
    class Employee : IComparable
    {
        public string Name { get; set; }
        public double Salary { get; set; }

        public Employee(string csvObject)
        {
            string[] values = csvObject.Split(",");

            Name = values[0];
            Salary = double.Parse(values[1], CultureInfo.InvariantCulture);
        }

        public int CompareTo(object obj)
        {
            if (!(obj is Employee))
                throw new ArgumentException("Comparing error: is not an Employee");

            Employee other = obj as Employee;

            return Name.CompareTo(other.Name);
        }

        public override string ToString()
        {
            return $"{Name}, {Salary.ToString("F2", CultureInfo.InvariantCulture)}";
        }
    }
}
