﻿using Applications.DTOs.Enums;
using System;
using System.ComponentModel.DataAnnotations;

namespace Application.DTOs
{
    public class SalesRecordDTO
    {
        public int Id { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime Date { get; set; }
        public double Amount { get; set; }
        public eSaleStatusDTO Status { get; set; }
        public SellerDTO Seller { get; set; }
    }
}
