﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Application.DTOs
{
    public class SellerDTO
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "{0} required")]
        public string Name { get; set; }
        [Required(ErrorMessage = "{0} required")]
        [EmailAddress(ErrorMessage = "Enter a valid email")]
        public string Email { get; set; }
        [Required(ErrorMessage = "{0} required")]
        [Display(Name = "Birth Date")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime BirthDate { get; set; }
        [Required(ErrorMessage = "{0} required")]
        [Display(Name = "Base Salary")]
        [DisplayFormat(DataFormatString = "{0:F2}")]
        public double BaseSalary { get; set; }
        [Display(Name = "Department")]
        public int DepartmentId { get; set; }
        public DepartmentDTO Department { get; set; }
        public ICollection<DepartmentDTO> Departments { get; set; }
        public ICollection<SalesRecordDTO> Sales { get; set; } = new List<SalesRecordDTO>();
    }
}
