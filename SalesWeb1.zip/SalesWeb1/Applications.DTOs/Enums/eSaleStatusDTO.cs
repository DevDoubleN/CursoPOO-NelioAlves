﻿namespace Applications.DTOs.Enums
{
    public enum eSaleStatusDTO
    {
        Pending = 0,
        Billed,
        Canceled
    }
}
