﻿using Application.DTOs;
using AutoMapper;
using Domain.Entities.Departments;
using Domain.Entities.SalesRecords;
using Domain.Entities.Sellers;

namespace Infrastructure.Core.Mapping
{
    public class UserProfile : Profile
    {
        public UserProfile()
        {
            CreateMap<Department, DepartmentDTO>();
            CreateMap<DepartmentDTO, Department>();

            CreateMap<SalesRecord, SalesRecordDTO>();
            CreateMap<SalesRecordDTO, SalesRecord>();

            CreateMap<Seller, SellerDTO>().ForMember(sel => sel.Departments, option => option.Ignore());
            CreateMap<SellerDTO, Seller>().ForMember(sel => sel.Department, option => option.Ignore());
        }
    }
}
