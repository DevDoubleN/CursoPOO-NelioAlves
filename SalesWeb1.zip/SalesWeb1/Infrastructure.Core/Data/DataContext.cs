﻿using Domain.Entities.Departments;
using Domain.Entities.SalesRecords;
using Domain.Entities.Sellers;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.IO;

namespace Infrastructure.Core.Data
{
    public class DataContext : DbContext
    {
        public DataContext() : base()
        {
        }

        public DataContext (DbContextOptions<DataContext> options)
            : base(options)
        {
        }

        public DbSet<Department> Department { get; set; }
        public DbSet<Seller> Seller { get; set; }
        public DbSet<SalesRecord> SalesRecord { get; set; }

        /// <summary>
        /// Only used to migrations
        /// </summary>
        /// <param name="optionsBuilder"></param>
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                IConfigurationRoot configuration = new ConfigurationBuilder()
                   .AddJsonFile(Directory.GetCurrentDirectory() + @"\Data\appsettings.json")
                   .Build();

                var connectionString = configuration.GetConnectionString("DataContext");
                optionsBuilder.UseMySql(connectionString, builder => builder.MigrationsAssembly("Infrastructure.Core"));                
            }
        }
    }
}
