﻿using Application.DTOs;
using Application.Services.Exceptions;
using Application.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using SalesWebMvcOriginal.Models.Generic;
using System.Diagnostics;
using System.Threading.Tasks;

namespace SalesWebMvcOriginal.Controllers
{
    public class SellersController : Controller
    {
        #region Properties
        private readonly ISellerService _sellerService;
        private readonly IDepartmentService _departmentService;
        #endregion

        #region Constructor
        public SellersController(ISellerService sellerService, IDepartmentService departmentService)
        {
            _sellerService = sellerService;
            _departmentService = departmentService;
        }
        #endregion

        // GET: Sellers
        public async Task<IActionResult> Index()
        {
            return View(await _sellerService.FindAll());
        }

        // GET: Sellers/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return RedirectToAction(nameof(Error), new { message = "Id not provided" });
            }

            var seller = await _sellerService.FindById((int)id);
            if (seller == null)
            {
                return RedirectToAction(nameof(Error), new { message = "Id not found" });
            }

            return View(seller);
        }

        // GET: Sellers/Create
        public IActionResult Create()
        {
            var departments = _departmentService.FindAll().Result;

            var viewModel = new SellerDTO { Departments = departments };
            return View(viewModel);
        }

        // POST: Sellers/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(SellerDTO seller)
        {
            if (ModelState.IsValid)
            {
                _sellerService.AddSeller(seller);

                return RedirectToAction(nameof(Index));
            }

            return View(seller);
        }

        // GET: Sellers/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return RedirectToAction(nameof(Error), new { message = "Id not provided" });
            }

            var seller = await _sellerService.FindById((int)id);
            if (seller == null)
            {
                return RedirectToAction(nameof(Error), new { message = "Id not found" });
            }

            seller.Departments = await _departmentService.FindAll();

            return View(seller);
        }

        // POST: Sellers/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, SellerDTO seller)
        {
            if (id != seller.Id)
            {
                return RedirectToAction(nameof(Error), new { message = "Id mismatch" });
            }

            if (ModelState.IsValid)
            {
                await _sellerService.UpdateSeller(seller);

                return RedirectToAction(nameof(Index));
            }
            return View(seller);
        }

        // GET: Sellers/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            try
            {
                if (id == null)
                {
                    return RedirectToAction(nameof(Error), new { message = "Id not provided" });
                }

                var seller = await _sellerService.FindById((int)id);
                if (seller == null)
                {
                    return RedirectToAction(nameof(Error), new { message = "Id not found" });
                }

                return View(seller);
            }
            catch (IntegrityException e)
            {
                return RedirectToAction(nameof(Error), new { message = e.Message });
            }
        }

        // POST: Sellers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await _sellerService.RemoveSeller(id);

            return RedirectToAction(nameof(Index));
        }

        private async Task<bool> SellerExists(int id)
        {
            var seller = await _sellerService.FindById(id);

            return seller.Id > 0;
        }

        public IActionResult Error(string message)
        {
            var viewModel = new ErrorViewModel
            {
                Message = message,
                RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier
            };

            return View(viewModel);
        }
    }
}
