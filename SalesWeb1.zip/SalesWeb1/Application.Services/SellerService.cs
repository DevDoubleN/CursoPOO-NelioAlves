﻿using Application.Services.Interfaces;
using Application.DTOs;
using Domain.Entities.Sellers;
using Infrastructure.Core.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Application.Services.Exceptions;

namespace Application.Services
{
    public class SellerService : ISellerService
    {
        #region Properties
        private readonly DataContext _context;
        private readonly IMapper _mapper;
        #endregion

        #region Constructor       
        public SellerService(DataContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }
        #endregion

        #region Members of ISellerService
        public async Task<List<SellerDTO>> FindAll()
        {
            var sellers = await _context.Seller.ToListAsync();

            return _mapper.Map<List<SellerDTO>>(sellers);
        }

        public async Task<SellerDTO> FindById(int id)
        {
            var seller = await _context.Seller.Where(s => s.Id == id).Include(dept => dept.Department).FirstOrDefaultAsync();

            return _mapper.Map<SellerDTO>(seller);
        }

        public async Task AddSeller(SellerDTO seller)
        {
            try
            {
                _context.Seller.Add(SellerFactory.CreateSeller(seller.Name, seller.Email, seller.BirthDate, seller.BaseSalary, seller.DepartmentId));
                await _context.SaveChangesAsync();
            }
            catch (DbConcurrencyException ex)
            {
                throw new DbConcurrencyException($"Concurrency exception! {ex.Message}");
            }
        }

        public async Task UpdateSeller(SellerDTO seller)
        {
            try
            {
                if(_context.Seller.Any(s => s.Id == seller.Id))
                {
                    var sel = _context.Seller.Where(s => s.Id == seller.Id).FirstOrDefault();

                    var entity = _mapper.Map<SellerDTO, Seller>(seller, sel);

                    _context.Seller.Update(entity);
                    await _context.SaveChangesAsync();
                }
                else
                    throw new NotFoundException("Id not found!");
            }
            catch (DbConcurrencyException ex)
            {
                throw new DbConcurrencyException($"Concurrency exception! {ex.Message}");
            }
        }

        public async Task RemoveSeller(int id)
        {
            try
            {
                if (id <= 0)
                {
                    throw new NotFoundException("Id is null or small than zero!");
                }
                else
                {
                    if (_context.Seller.Any(s => s.Id == id))
                    {
                        var seller = _context.Seller.Where(s => s.Id == id).FirstOrDefault();
                        _context.Seller.Remove(seller);

                        await _context.SaveChangesAsync();
                    }
                    else
                        throw new NotFoundException("Id not found!");
                }
            }
            catch (DbConcurrencyException ex)
            {
                throw new DbConcurrencyException($"Concurrency exception! {ex.Message}");
            }
            catch (DbUpdateException ex)
            {
                throw new IntegrityException($"Integrity exception! {ex.Message}");
            }
        }

        public async Task<double> TotalSales(SellerDTO sellerDTO, DateTime initial, DateTime final)
        {
            var sellerValue = await _context.Seller.Where(s => s.Id == sellerDTO.Id).FirstOrDefaultAsync();
            var seller = _mapper.Map<Seller>(sellerValue);
            return await Task.FromResult(_context.SalesRecord.Where(sr => sr.Seller == seller && sr.Date >= initial 
                                                                        && sr.Date <= final).Sum(sr => sr.Amount));
        }
        #endregion
    }
}
