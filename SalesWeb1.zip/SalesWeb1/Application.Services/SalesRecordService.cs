﻿using Application.Services.Interfaces;
using Application.DTOs;
using Domain.Entities.SalesRecords;
using Infrastructure.Core.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Domain.Enums;
using Application.Services.Exceptions;

namespace Application.Services
{
    public class SalesRecordService : ISalesRecordService
    {
        #region Properties
        private readonly DataContext _context;
        private readonly IMapper _mapper;
        #endregion

        #region Constructor
        public SalesRecordService(DataContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }
        #endregion

        #region Members of ISalesRecordService
        public async Task<List<SalesRecordDTO>> FindAll()
        {
            var salesRecords = await _context.SalesRecord.ToListAsync();

            return _mapper.Map<List<SalesRecordDTO>>(salesRecords);
        }

        public async Task<SalesRecordDTO> FindById(int id)
        {
            var salesRecord = await _context.SalesRecord.Where(x => x.Id == id).FirstOrDefaultAsync();

            return _mapper.Map<SalesRecordDTO>(salesRecord);
        }

        public async Task AddSale(SalesRecordDTO sr)
        {
            try
            {
                _context.SalesRecord.Add(SalesRecordFactory.CreateSalesRecord(sr.Date, sr.Amount, (eSaleStatus)sr.Status, sr.Id));
                await _context.SaveChangesAsync();
            }
            catch (DbConcurrencyException ex)
            {
                throw new DbConcurrencyException($"Concurrency exception! {ex.Message}");
            }
        }

        public async Task UpdateSales(SalesRecordDTO sr)
        {
            try
            {
                if (_context.SalesRecord.Any(s => s.Id == sr.Id))
                {
                    _context.SalesRecord.Update(SalesRecordFactory.CreateSalesRecord(sr.Date, sr.Amount, (eSaleStatus)sr.Status, sr.Id));
                    await _context.SaveChangesAsync();
                }
                else
                    throw new NotFoundException("Id not found!");
            }
            catch(DbConcurrencyException ex)
            {
                throw new DbConcurrencyException($"Concurrency exception! {ex.Message}");
            }
        }

        public async Task RemoveSale(int id)
        {
            try
            {
                if (id <= 0)
                    throw new NotFoundException("Id is null or small than zero!");
                else
                {
                    if (_context.SalesRecord.Any(s => s.Id == id))
                    {
                        var salesRecord = _context.SalesRecord.Where(sel => sel.Id == id).FirstOrDefault();

                        _context.SalesRecord.Remove(salesRecord);
                        await _context.SaveChangesAsync();
                    }
                    else
                        throw new NotFoundException("Id not found!");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<double> TotalSalesFromDepartment(DepartmentDTO departmentDTO, DateTime initial, DateTime final)
        {
            return await Task.FromResult(_context.SalesRecord.Where(sr => sr.Seller.Department.Id == departmentDTO.Id && sr.Date >= initial
                                                                        && sr.Date <= final).Sum(sr => sr.Amount));
        }

        public async Task<double> TotalSalesFromSeller(SellerDTO sellerDTO, DateTime initial, DateTime final)
        {
            return await Task.FromResult(_context.SalesRecord.Where(sr => sr.Seller.Id == sellerDTO.Id && sr.Date >= initial
                                                                        && sr.Date <= final).Sum(sr => sr.Amount));
        }

        public async Task<List<SalesRecordDTO>> FindByDate(DateTime? minDate, DateTime? maxDate)
        {
            var sales = from obj in _context.SalesRecord select obj;

            if (minDate.HasValue)
                sales = sales.Where(r => r.Date >= minDate.Value);
            if (maxDate.HasValue)
                sales = sales.Where(r => r.Date <= maxDate.Value);

            await sales.Include(r => r.Seller).Include(r => r.Seller.Department).OrderByDescending(r => r.Date).ToListAsync();

            return _mapper.Map<List<SalesRecordDTO>>(sales); ;
        }
        #endregion
    }
}
