﻿using System;

namespace Application.Services.Exceptions
{
    class NotFoundException : ApplicationException
    {
        public NotFoundException(string message) : base(message)
        {
        }
    }
}
