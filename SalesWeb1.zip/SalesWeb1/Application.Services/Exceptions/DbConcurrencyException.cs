﻿using System;

namespace Application.Services.Exceptions
{
    class DbConcurrencyException : ApplicationException
    {
        public DbConcurrencyException(string message) : base(message)
        {
        }
    }
}
