﻿using Application.DTOs;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Application.Services.Interfaces
{
    public interface IDepartmentService
    {
        Task<ICollection<DepartmentDTO>> FindAll();
        Task<DepartmentDTO> FindById(int id);
        Task AddDepartment(DepartmentDTO department);
        Task UpdateDepartment(DepartmentDTO department);
        Task RemoveDepartment(int id);
        Task<double> TotalSalesFromDepartment(DepartmentDTO department, DateTime initial, DateTime final);
    }
}
