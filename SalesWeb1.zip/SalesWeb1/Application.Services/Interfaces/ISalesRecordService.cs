﻿using Application.DTOs;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Application.Services.Interfaces
{
    public interface ISalesRecordService
    {
        Task<List<SalesRecordDTO>> FindAll();
        Task<SalesRecordDTO> FindById(int id);
        Task AddSale(SalesRecordDTO sr);
        Task UpdateSales(SalesRecordDTO sr);
        Task RemoveSale(int id);
        Task<double> TotalSalesFromSeller(SellerDTO seller, DateTime initial, DateTime final);
        Task<double> TotalSalesFromDepartment(DepartmentDTO department, DateTime initial, DateTime final);
        Task<List<SalesRecordDTO>> FindByDate(DateTime? minDate, DateTime? maxDate);
    }
}
