﻿using Application.DTOs;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Application.Services.Interfaces
{
    public interface ISellerService
    {
        Task<List<SellerDTO>> FindAll();
        Task<SellerDTO> FindById(int id);
        Task AddSeller(SellerDTO seller);
        Task UpdateSeller(SellerDTO seller);
        Task RemoveSeller(int id);
        Task<double> TotalSales(SellerDTO seller, DateTime initial, DateTime final);
    }
}
