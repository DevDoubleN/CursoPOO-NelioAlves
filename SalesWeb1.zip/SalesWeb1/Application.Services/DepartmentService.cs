﻿using Application.Services.Interfaces;
using Application.DTOs;
using Domain.Entities.Departments;
using Infrastructure.Core.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Application.Services.Exceptions;

namespace Application.Services
{
    public class DepartmentService : IDepartmentService
    {
        #region Properties
        private readonly DataContext _context;
        private readonly ISellerService _sellerService;
        private readonly IMapper _mapper;
        #endregion

        #region Constructor
        public DepartmentService(DataContext context, ISellerService sellerService, IMapper mapper)
        {
            _context = context;
            _sellerService = sellerService;
            _mapper = mapper;
        }
        #endregion

        #region Members of IDepartmentService
        public async Task<ICollection<DepartmentDTO>> FindAll()
        {
            var departments = await _context.Department.ToListAsync();

            return _mapper.Map<List<DepartmentDTO>>(departments);
        }

        public async Task<DepartmentDTO> FindById(int id)
        {
            var department = await _context.Department.Where(x => x.Id == id).FirstOrDefaultAsync();

            return _mapper.Map<DepartmentDTO>(department);
        }

        public async Task AddDepartment(DepartmentDTO department)
        {
            try
            {
                _context.Department.Add(DepartmentFactory.CreateDepartment(department.Name));
                await _context.SaveChangesAsync();
            }
            catch(DbConcurrencyException ex)
            {
                throw new DbConcurrencyException($"Concurrency exception! {ex.Message}");
            }
        }

        public async Task UpdateDepartment(DepartmentDTO department)
        {
            try
            {
                if (_context.Department.Any(d => d.Id == department.Id))
                {
                    var dep = _context.Department.Where(d => d.Id == department.Id).FirstOrDefault();

                    var entity = _mapper.Map<DepartmentDTO, Department>(department, dep);

                    _context.Department.Update(entity);
                    await _context.SaveChangesAsync();
                }
                else
                    throw new NotFoundException("Id not found!");
            }
            catch(DbConcurrencyException ex)
            {
                throw new DbConcurrencyException($"Concurrency exception! {ex.Message}");
            }
        }

        public async Task RemoveDepartment(int id)
        {
            try
            {
                if (id <= 0)
                    throw new NotFoundException("Id is null or small than zero!");
                else
                {
                    if (_context.Department.Any(d => d.Id == id))
                    {
                        var department = _context.Department.Where(sel => sel.Id == id).FirstOrDefault();

                        _context.Department.Remove(department);
                        await _context.SaveChangesAsync();
                    }
                    else
                        throw new NotFoundException($"Id not found!");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<double> TotalSalesFromDepartment(DepartmentDTO department, DateTime initial, DateTime final)
        {
            double total = 0;

            foreach(SellerDTO seller in department.Sellers)
            {
                total += await _sellerService.TotalSales(seller, initial, final);
            }

            return total;
        }
        #endregion
    }
}
