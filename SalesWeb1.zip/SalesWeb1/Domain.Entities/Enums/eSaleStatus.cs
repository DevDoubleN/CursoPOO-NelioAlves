﻿namespace Domain.Enums
{
    public enum eSaleStatus
    {
        Pending = 0,
        Billed,
        Canceled
    }
}
