﻿using System;

namespace Domain.Entities.Sellers
{
    public static class SellerFactory
    {
        public static Seller CreateSeller(string name, string email, DateTime birthDate, double baseSalary, int departmentId)
        {
            Seller seller = new Seller();

            seller.Name = name;
            seller.Email = email;
            seller.BirthDate = birthDate;
            seller.BaseSalary = baseSalary;
            seller.DepartmentId = departmentId;

            return seller;
        }
    }
}
