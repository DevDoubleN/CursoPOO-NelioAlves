﻿using Domain.Entities.Sellers;
using Domain.Enums;
using System;

namespace Domain.Entities.SalesRecords
{
    public class SalesRecord
    {
        #region Properties
        public int Id { get; set; }
        public DateTime Date { get; set; }
        public double Amount { get; set; }
        public eSaleStatus Status { get; set; }
        public Seller Seller { get; set; }
        #endregion

        #region Constructors
        public SalesRecord()
        {
        }

        public SalesRecord(int id, DateTime date, double amount, eSaleStatus status, Seller seller)
        {
            Id = id;
            Date = date;
            Amount = amount;
            Status = status;
            Seller = seller;
        }
        #endregion
    }
}
