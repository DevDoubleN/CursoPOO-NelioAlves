﻿using Domain.Entities.Sellers;
using Domain.Enums;
using System;

namespace Domain.Entities.SalesRecords
{
    public static class SalesRecordFactory
    {
        public static SalesRecord CreateSalesRecord(DateTime date, double amount, eSaleStatus status, int idSeller)
        {
            SalesRecord salesRecord = new SalesRecord();

            salesRecord.Date = date;
            salesRecord.Amount = amount;
            salesRecord.Status = status;
            salesRecord.Seller.Id = idSeller;

            return salesRecord;
        }
    }
}
