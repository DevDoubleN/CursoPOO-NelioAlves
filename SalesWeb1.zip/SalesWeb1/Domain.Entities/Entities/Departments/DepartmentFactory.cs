﻿namespace Domain.Entities.Departments
{
    public static class DepartmentFactory
    {
        public static Department CreateDepartment(string name)
        {
            Department department = new Department();

            department.Name = name;

            return department;
        }
    }
}
