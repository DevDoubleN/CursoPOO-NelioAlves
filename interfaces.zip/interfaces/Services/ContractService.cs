﻿using interfaces.Models.Entities;
using interfaces.Services.Interfaces;

namespace interfaces.Services
{
    class ContractService
    {
        private IOnlinePaymentService _onlinePaymentService;

        public ContractService(IOnlinePaymentService contractService)
        {
            _onlinePaymentService = contractService;
        }

        public void ProcessContract(Contract contract, int months)
        {
            double valuePerInstallment = contract.TotalValue / months;

            for (int x = 1; x <= months; x++)
            {
                Installment installment = new Installment();

                installment.Amount = _onlinePaymentService.Interest(valuePerInstallment, x);
                installment.Amount = _onlinePaymentService.PaymentFee(installment.Amount);
                installment.DueDate = contract.Date.AddMonths(x);

                contract.Installments.Add(installment);
            }
        }
    }
}
