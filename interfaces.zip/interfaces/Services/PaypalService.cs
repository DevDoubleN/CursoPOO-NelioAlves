﻿using interfaces.Services.Interfaces;

namespace interfaces.Services
{
    class PaypalService : IOnlinePaymentService
    {
        public double Interest(double amount, int months)
        {
            return amount + ((amount / 100 * 1) * months);
        }

        public double PaymentFee(double amount)
        {
            return amount + (amount / 100 * 2);
        }
    }
}
