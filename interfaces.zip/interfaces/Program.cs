﻿using interfaces.Models.Entities;
using interfaces.Services;
using System;
using System.Collections.Generic;
using System.Globalization;

namespace interfaces
{
    class Program
    {
        static void Main(string[] args)
        {
            ContractService _contractService = new ContractService(new PaypalService());

            Console.WriteLine("Enter contract data:");

            Console.Write("Number: ");
            int number = int.Parse(Console.ReadLine());

            Console.Write("Date (DD/MM/YYYY): ");
            DateTime date = DateTime.ParseExact(Console.ReadLine(), "dd/MM/yyyy", CultureInfo.InvariantCulture);

            Console.Write("Contract value: ");
            double value = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);

            Console.Write("Enter number of installments: ");
            int installments = int.Parse(Console.ReadLine());

            Contract contract = new Contract(number, date, value, new List<Installment>());
            _contractService.ProcessContract(contract, installments);

            Console.WriteLine("\nInstallments: ");
            foreach(var installment in contract.Installments)
                Console.WriteLine(installment);
        }
    }
}
