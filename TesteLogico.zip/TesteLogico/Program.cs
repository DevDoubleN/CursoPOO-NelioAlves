﻿using System;
using System.Globalization;

namespace TesteLogico
{
    public class Program
    {
        static void Main(string[] args)
        {
            int opcao;
            Console.WriteLine("Escolha qual o exercício quer resolver:");
            opcao = int.Parse(Console.ReadLine());

            try
            {
                switch (opcao)
                {
                    case 0:
                        Exercicio1();
                        break;

                    case 1:
                        Exercicio12();
                        break;

                    case 2:
                        Exercicio2();
                        break;

                    case 3:
                        Exercicio22();
                        break;

                    case 4:
                        Exercicio3();
                        break;

                    case 5:
                        Exercicio32();
                        break;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static void Exercicio1()
        {
            int Codigo1, Codigo2, Quantidade1, Quantidade2;
            double Preco1, Preco2, Total;

            Console.Write("Código: ");
            Codigo1 = int.Parse(Console.ReadLine());
            Console.Write("Quantidade: ");
            Quantidade1 = int.Parse(Console.ReadLine());
            Console.Write("Preço: ");
            Preco1 = double.Parse(Console.ReadLine());

            Console.Write("Código: ");
            Codigo2 = int.Parse(Console.ReadLine());
            Console.Write("Quantidade: ");
            Quantidade2 = int.Parse(Console.ReadLine());
            Console.Write("Preço: ");
            Preco2 = double.Parse(Console.ReadLine());

            Total = (Quantidade1 * Preco1) + (Quantidade2 * Preco2);
            Console.WriteLine("VALOR A PAGAR: {0:c}", Total);
        }

        public static void Exercicio12()
        {
            double area = 0;
            double pi = 3.14159;
            double r = 0;

            Console.Write("Raio: ");
            r = double.Parse(Console.ReadLine());
            area = pi * (Math.Pow(r, 2));

            Console.WriteLine("A: {0}", area.ToString("N4"));
        }

        public static void Exercicio2()
        {
            int Codigo, Quantidade;
            string[] Especificacao = new string[5] { "Cachorro Quente", "X-Salada", "X-Bacon", "Torrada Simples", "Refrigerante" };
            double Preco = 0;

            Console.WriteLine("==================================");
            Console.WriteLine("1 - Cachorro Quente - R$ 4,00");
            Console.WriteLine("2 - X-Salada - R$ 4,50");
            Console.WriteLine("3 - X-Bacon - R$ 5,00");
            Console.WriteLine("4 - Torrada Simples - R$ 2,00");
            Console.WriteLine("5 - Refigerante - R$ 1,50");
            Console.WriteLine("==================================");
            Console.WriteLine("Escolha algum item pelo seu código: ");
            Codigo = int.Parse(Console.ReadLine());
            Console.WriteLine("Escolha a quantidade: ");
            Quantidade = int.Parse(Console.ReadLine());

            if (Codigo == 1)
            {
                Preco = 4.00 * Quantidade;
                Console.WriteLine("{0} unidades de: {1}-{2} no valor de {3:c}", Quantidade, Codigo, Especificacao[0], 4.00);
            }
            else if (Codigo == 2)
            {
                Preco = 4.50 * Quantidade;
                Console.WriteLine("{0} unidades de: {1}-{2} no valor de {3:c}", Quantidade, Codigo, Especificacao[1], 4.50);
            }
            else if (Codigo == 3)
            {
                Preco = 5 * Quantidade;
                Console.WriteLine("{0} unidades de: {1}-{2} no valor de {3:c}", Quantidade, Codigo, Especificacao[2], 5.00);
            }
            else if (Codigo == 4)
            {
                Preco = 2 * Quantidade;
                Console.WriteLine("{0} unidades de: {1}-{2} no valor de {3:c}", Quantidade, Codigo, Especificacao[3], 2.00);
            }
            else if (Codigo == 5)
            {
                Preco = 1.5 * Quantidade;
                Console.WriteLine("{0} unidades de: {1}-{2} no valor de {3:c}", Quantidade, Codigo, Especificacao[4], 1.50);
            }

            Console.WriteLine("Total: {0:c}", Preco);
        }

        public static void Exercicio22()
        {
        }

        public static void Exercicio3()
        {
            string senha = "2002";
            string input = "";
            Console.WriteLine("Digite a senha:");
            input = Console.ReadLine();

            do
            {
                Console.WriteLine("Senha inválida! Tente novamente... ");
                Console.WriteLine("Digite a senha:");
                input = Console.ReadLine();
            } while (senha != input);
            if (senha == input)
            {
                Console.WriteLine("Acesso permitido");
            }
        }

        public static void Exercicio32()
        {
            int[] arrayInt;
            int x;
            int tem = 0;
            int naoTem = 0;

            Console.WriteLine("Digite quantos números serão inseridos:");
            x = int.Parse(Console.ReadLine());
            arrayInt = new int[x];
            int aux = 1;
            for(int i = 0; i < x; i++)
            {
                Console.WriteLine(aux + "º número:");
                arrayInt[i] = int.Parse(Console.ReadLine());
                aux++;
                if(arrayInt[i] >= 10 && arrayInt[i] <= 20)
                {
                    tem++;
                }
                else
                {
                    naoTem++;
                }
            }

            Console.WriteLine("Contém {0} números dentro do intervalo.", tem);
            Console.WriteLine("Contém {0} números fora do intervalo.", innaoTem);
        }
    }
}
