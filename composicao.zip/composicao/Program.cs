﻿using System;
using System.Globalization;
using composicao.Entities;
using composicao.Entities.Enums;

namespace composicao
{
    class Program
    {
        static void Main(string[] args)
        {
            Order order = new Order();

            Console.WriteLine("Enter client data:");

            Console.Write("Name: ");
            string name = Console.ReadLine();
            Console.Write("Email: ");
            string email = Console.ReadLine();
            Console.Write("Birth date (DD/MM/YYYY): ");
            DateTime birthDate = DateTime.Parse(Console.ReadLine());
            order.Client = new Client(name, email, birthDate);

            Console.WriteLine("Enter order data:");

            Console.Write("Status: ");
            order.Status = Enum.Parse<OrderStatus>(Console.ReadLine());

            Console.Write("How many items to this order? ");
            int n = int.Parse(Console.ReadLine());

            for(int x = 1; x <= n; x++)
            {
                Console.WriteLine($"Enter #{x} item data:");
                Console.Write("Product name: ");
                string productName = Console.ReadLine();
                Console.Write("Product price: ");
                double productPrice = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);

                Product product = new Product(productName, productPrice);

                Console.Write("Quantity: ");
                int quantity = int.Parse(Console.ReadLine());

                OrderItem orderItem = new OrderItem(quantity, productPrice, product);

                order.AddItem(orderItem);
            }

            Console.WriteLine();
            Console.WriteLine("ORDER SUMMARY:");
            Console.WriteLine(order.ToString());
        }
    }
}
