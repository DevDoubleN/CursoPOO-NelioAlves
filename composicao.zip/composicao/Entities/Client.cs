﻿using System;

namespace composicao.Entities
{
    public class Client
    {
        private string Name { get; set; }
        private string Email { get; set; }
        private DateTime BirthDate { get; set; }

        public Client()
        {
        }
        public Client(string name, string email, DateTime birthDate)
        {
            Name = name;
            Email = email;
            BirthDate = birthDate;
        }

        public override string ToString()
        {
            return $"Client: {Name} ({BirthDate.ToString("dd/MM/yyyy")}) - {Email}";
        }
    }
}
