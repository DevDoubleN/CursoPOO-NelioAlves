﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Globalization;
using composicao.Entities.Enums;

namespace composicao.Entities
{
    class Order
    {
        public Client Client { get; set; }
        public DateTime Moment { get; set; } = DateTime.Now;
        public OrderStatus Status { get; set; }
        public List<OrderItem> OrderItems { get; set; } = new List<OrderItem>();

        public void AddItem(OrderItem orderItem)
        {
            OrderItems.Add(orderItem);
        }
        public void RemoveItem(OrderItem orderItem)
        {
            OrderItems.Remove(orderItem);
        }
        public double Total()
        {
            double sum = 0;

            foreach(var orderItem in OrderItems)
            {
                sum += orderItem.SubTotal();
            }

            return sum;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"Order moment: {Moment.ToString("dd/MM/yyyy hh:mm:ss")}");
            sb.AppendLine($"Order status: {Status}");
            sb.AppendLine($"{Client.ToString()}");
            sb.AppendLine("Order items:");

            foreach(var orderItem in OrderItems)
            {
                sb.AppendLine(orderItem.ToString());
            }

            sb.AppendLine($"Total price: ${Total().ToString("F2", CultureInfo.InvariantCulture)}");

            return sb.ToString();
        }
    }
}
