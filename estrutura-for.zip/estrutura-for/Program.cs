﻿using System;

namespace estrutura_for
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Informe qual exercício deseja fazer ou pressione 0 para sair...");
                int exercicioEscolhido = int.Parse(Console.ReadLine());
                Console.Clear();
                int valor = 0;
                int value = 0;

                while (exercicioEscolhido != 0)
                {
                    switch (exercicioEscolhido)
                    {
                        case 1:
                            //Leia um valor inteiro X (1 <= X <= 1000). Em seguida mostre os ímpares de 1 até X, um valor por linha, inclusive o 
                            // X, se for o caso.

                            Console.WriteLine("Digite um valor inteiro: ");
                            valor = int.Parse(Console.ReadLine());

                            for(int x = 0; x <= valor; x++)
                            {
                                if (x % 2 == 1)
                                    Console.WriteLine(x);
                            }

                            break;
                        case 2:
                            //Leia um valor inteiro N.Este valor será a quantidade de valores inteiros X que serão lidos em seguida.
                            //Mostre quantos destes valores X estão dentro do intervalo[10, 20] e quantos estão fora do intervalo, mostrando
                            //essas informações conforme exemplo(use a palavra "in" para dentro do intervalo, e "out" para fora do intervalo).

                            Console.WriteLine("Digite um valor inteiro: ");
                            valor = int.Parse(Console.ReadLine());
                            int dentro = 0;
                            int fora = 0;

                            for(int x = 0; x < valor; x++)
                            {
                                value = int.Parse(Console.ReadLine());

                                if (value >= 10 && value <= 20)
                                    dentro++;
                                else
                                    fora++;
                            }

                            Console.WriteLine($"Dentro: {dentro}");
                            Console.WriteLine($"Fora: {fora}");

                            break;
                        case 3:
                            //Leia 1 valor inteiro N, que representa o número de casos de teste que vem a seguir. Cada caso de teste consiste
                            //de 3 valores reais, cada um deles com uma casa decimal.Apresente a média ponderada para cada um destes
                            //conjuntos de 3 valores, sendo que o primeiro valor tem peso 2, o segundo valor tem peso 3 e o terceiro valor tem
                            //peso 5.

                            Console.WriteLine("Digite um valor inteiro: ");
                            valor = int.Parse(Console.ReadLine());
                            string[] strValue = new string[valor];
                            decimal dec = 0;
                            decimal resultado = 0;

                            for(int x = 0; x < valor; x++)
                            {
                                strValue = Console.ReadLine().Split(" ");

                                for(int y = 0; y < valor; y++)
                                {
                                    dec += decimal.Parse(strValue[y]);
                                }

                                resultado = dec / valor;

                                Console.WriteLine(resultado.ToString("F1"));
                            }

                            break;
                        case 4:
                            //Fazer um programa para ler um número N. Depois leia N pares de números e mostre a divisão do primeiro pelo
                            //segundo.Se o denominador for igual a zero, mostrar a mensagem "divisao impossivel".

                            Console.WriteLine("Digite um valor inteiro: ");
                            valor = int.Parse(Console.ReadLine());
                            strValue = new string[valor];
                            int[] arrayInteger = new int[valor];
                            decimal value1 = 0;
                            decimal value2 = 0;
                            decimal resposta = 0;

                            for (int x = 0; x < valor; x++)
                            {
                                strValue = Console.ReadLine().Split(" ");

                                for(int y = 0; y < 2; y++)
                                {
                                    value1 = int.Parse(strValue[0]);
                                    value2 = int.Parse(strValue[1]);
                                }

                                if (value2 == 0)
                                    Console.WriteLine("Divisão impossível");
                                else
                                {
                                    resposta = value1 / value2;
                                    Console.WriteLine(resposta.ToString("F1"));
                                }
                            }

                            break;
                        case 5:
                            //Ler um valor N. Calcular e escrever seu respectivo fatorial. Fatorial de N = N * (N - 1) * (N - 2) * (N - 3) * ... *1.
                            //Lembrando que, por definição, fatorial de 0 é 1.

                            Console.WriteLine("Digite um valor inteiro: ");
                            valor = int.Parse(Console.ReadLine());
                            int fatorial = valor;
                            value = 0;

                            for(int x = 1; x < valor; x++)
                            {
                                value = (valor - x);
                                fatorial *= value; 
                            }

                            if (fatorial == 0)
                                fatorial = 1;

                            Console.WriteLine(fatorial);

                            break;
                        case 6:
                            //Ler um número inteiro N e calcular todos os seus divisores.

                            Console.WriteLine("Digite um valor inteiro: ");
                            valor = int.Parse(Console.ReadLine());

                            for(int x = valor; x > 0; x--)
                            {
                                if(valor % x == 0)
                                    Console.WriteLine(valor / x);
                            }

                            break;
                        case 7:
                            //Fazer um programa para ler um número inteiro positivo N. O programa deve então mostrar na tela N linhas, 
                            //começando de 1 até N. Para cada linha, mostrar o número da linha, depois o quadrado e o cubo do valor, conforme
                            //exemplo.

                            Console.WriteLine("Digite um valor inteiro positivo: ");
                            valor = int.Parse(Console.ReadLine());
                            if (valor < 0)
                            {
                                Console.WriteLine("Valor inválido!");
                                valor = int.Parse(Console.ReadLine());
                            }

                            for(int x = 1; x <= valor; x++)
                            {
                                Console.WriteLine($"{x} {x*x} {(x*x)*x}");
                            }

                            break;

                        Console.WriteLine("Informe qual exercício deseja fazer ou pressione 0 para sair...");
                        exercicioEscolhido = int.Parse(Console.ReadLine());
                        Console.Clear();
                    }

                    Console.WriteLine("Informe qual exercício deseja fazer ou pressione 0 para sair...");
                    exercicioEscolhido = int.Parse(Console.ReadLine());
                    Console.Clear();
                }
            }
            catch
            {
                Console.WriteLine("Opção inválida!!!");
            }
        }
    }
}
