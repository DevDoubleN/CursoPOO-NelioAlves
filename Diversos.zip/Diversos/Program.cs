﻿using System;
using System.Globalization;

namespace Diversos
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Apenas a apresentação de alguns conteúdos relacionados ao curso de C# e POO, ministrado pelo Profº Nélio Alves...");

            ChamaOpcoes();

            try
            {
                int opcao = int.Parse(Console.ReadLine());

                while (opcao > 0)
                {
                    switch (opcao)
                    {
                        case 1:
                            sbyte sb1 = sbyte.MinValue;
                            sbyte sb2 = sbyte.MaxValue;
                            short sh1 = short.MinValue;
                            short sh2 = short.MaxValue;
                            int i1 = int.MinValue;
                            int i2 = int.MaxValue;
                            long lg1 = long.MinValue;
                            long lg2 = long.MaxValue;
                            byte b1 = byte.MinValue;
                            byte b2 = byte.MaxValue;
                            ushort us1 = ushort.MinValue;
                            ushort us2 = ushort.MaxValue;
                            uint ui1 = uint.MinValue;
                            uint ui2 = uint.MaxValue;
                            ulong ul1 = ulong.MinValue;
                            ulong ul2 = ulong.MaxValue;
                            float fl1 = float.MinValue;
                            float fl2 = float.MaxValue;
                            double dbl1 = double.MinValue;
                            double dbl2 = double.MaxValue;
                            decimal d1 = decimal.MinValue;
                            decimal d2 = decimal.MaxValue;
                            bool t = true;
                            bool f = false;

                            Console.WriteLine($"Type sbyte min. value: {sb1}");
                            Console.WriteLine($"Type sbyte max. value: {sb2}");
                            Console.WriteLine($"Type short min. value: {sh1}");
                            Console.WriteLine($"Type short max. value: {sh2}");
                            Console.WriteLine($"Type int min. value: {i1}");
                            Console.WriteLine($"Type int max. value: {i2}");
                            Console.WriteLine($"Type long min. value: {lg1}");
                            Console.WriteLine($"Type long max. value: {lg2}");
                            Console.WriteLine($"Type byte min. value: {b1}");
                            Console.WriteLine($"Type byte max. value: {b2}");
                            Console.WriteLine($"Type ushort min. value: {us1}");
                            Console.WriteLine($"Type ushort max. value: {us2}");
                            Console.WriteLine($"Type uint min. value: {ui1}");
                            Console.WriteLine($"Type uint max. value: {ui2}");
                            Console.WriteLine($"Type ulong min. value: {ul1}");
                            Console.WriteLine($"Type ulong max. value: {ul2}");
                            Console.WriteLine($"Type float min. value: {fl1}");
                            Console.WriteLine($"Type float max. value: {fl2}");
                            Console.WriteLine($"Type double min. value: {dbl1}");
                            Console.WriteLine($"Type double max. value: {dbl2}");
                            Console.WriteLine($"Type decimal min. value: {d1}");
                            Console.WriteLine($"Type decimal max. value: {d2}");
                            Console.WriteLine($"Type boolean value: {t} or {f}");

                            //int idade = 32;
                            //double saldo = 10.35784;
                            //string nome = "Maria";

                            // PLACE HOLDER
                            //Console.WriteLine("{0} tem {1} anos e tem saldo igual a {2:F2} reais", nome, idade, saldo);
                            // POLARIZAÇÃO
                            //Console.WriteLine($"{nome} tem {idade} anos e tem saldo igual a {saldo:F2} reais");
                            // CONCATENAÇÃO
                            //Console.WriteLine(nome + " tem " + idade + " anos e tem saldo igual a " + saldo.ToString("F2") + " reais");
                            break;
                        case 2:
                            string produto1 = "Computador";
                            string produto2 = "Mesa de escritório";

                            int idade = 30;
                            int codigo = 5290;
                            char genero = 'M';

                            double preco1 = 2100.0;
                            double preco2 = 650.50;
                            double medida = 53.234567;

                            Console.WriteLine("Produtos:");
                            Console.WriteLine("{0}, cujo preço é $ {1:F2}", produto1, preco1);
                            Console.WriteLine("{0}, cujo preço é $ {1:F2}\n", produto2, preco2);
                            Console.WriteLine("Registro: {0} anos de idade, código {1} e gênero: {2}\n", idade, codigo, genero);
                            Console.WriteLine("Medida de oito casas decimais: {0:F8}", medida);
                            Console.WriteLine("Arredondado (três casas decimais): {0:F3}", medida);
                            Console.WriteLine("Separador decimal invariant culture: " + medida.ToString("F3" + CultureInfo.InvariantCulture));
                            break;
                        case 3:
                            int n1 = 3 + 4 * 2;
                            int n2 = (3 + 4) * 2;
                            int n3 = 17 % 3;
                            double n4 = 10.0 / 8;

                            double a = 1.0, b = -3.0, c = -4.0;

                            double delta = Math.Pow(b, 2) - 4.0 * a * c;

                            double x1 = (-b + Math.Sqrt(delta)) / (2.0 * a); // Primeiro resultado da equação
                            double x2 = (-b - Math.Sqrt(delta)) / (2.0 * a); // Segundo resultado da equação

                            Console.WriteLine(n1);
                            Console.WriteLine(n2);
                            Console.WriteLine(n3);
                            Console.WriteLine(n4);
                            Console.WriteLine(delta);
                            Console.WriteLine(x1);
                            Console.WriteLine(x2);

                            break;
                        case 4:
                            Console.WriteLine("Entre com seu nome completo:");
                            string nome = Console.ReadLine();
                            Console.WriteLine("Quantos quartos tem na sua casa?");
                            int quartos = int.Parse(Console.ReadLine());
                            Console.WriteLine("Entre com o preço de um produto:");
                            double preco = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);
                            Console.WriteLine("Entre seu último nome, idade e altura (mesma linha):");
                            string[] nomeIdadeAltura = Console.ReadLine().Split(' ');


                            Console.WriteLine(nome);
                            Console.WriteLine(quartos);
                            Console.WriteLine(preco.ToString("F2", CultureInfo.InvariantCulture));
                            Console.WriteLine(nomeIdadeAltura[0]);
                            Console.WriteLine(nomeIdadeAltura[1]);
                            Console.WriteLine(nomeIdadeAltura[2]);
                            break;
                    }

                    Console.ReadKey();
                    Console.Clear();
                    ChamaOpcoes();
                    opcao = int.Parse(Console.ReadLine());
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Opção inválida..." + ex.Message);
            }
        }

        public static void ChamaOpcoes()
        {
            Console.WriteLine("---------------------------------------");
            Console.WriteLine("Escolha uma das opções disponíveis:");
            Console.WriteLine("1 - Tipos de valor com seus mínimos e máximos");
            Console.WriteLine("2 - Tipos de saídas de dados");
            Console.WriteLine("3 - Operadores aritméticos");
            Console.WriteLine("4 - Interações de entrada e saída");
            Console.WriteLine("---------------------------------------");
        }
    }
}
