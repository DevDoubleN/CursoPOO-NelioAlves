﻿using exception.Entities;
using exception.Entities.Exceptions;
using System;
using System.Globalization;

namespace exception
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Account account = new Account();

                Console.WriteLine("Enter account data: ");

                Console.Write("Number: ");
                account.Number = int.Parse(Console.ReadLine());

                Console.Write("Holder: ");
                account.Holder = Console.ReadLine();

                Console.Write("Initial balance: ");
                account.Balance = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);

                Console.Write("Withdraw limit: ");
                account.WithdrawLimit = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);

                Console.Write("\n\nEnter amount for withdraw: ");
                account.WithDraw(double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture));

                Console.Write($"New balance: {account.Balance.ToString("F2", CultureInfo.InvariantCulture)}");
            }
            catch(DomainException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch(FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
